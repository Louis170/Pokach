// Vercel-Funktion: gibt die öffentliche IP des Aufrufers zurück.
// Pokach nutzt sie, um Geräte im selben WLAN zu finden (gleiche IP = gleiches WLAN).
// Es wird nichts gespeichert.
module.exports = (req, res) => {
  const fwd = String(req.headers['x-forwarded-for'] || '');
  const ip = fwd.split(',')[0].trim() || (req.socket && req.socket.remoteAddress) || '';
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ ip }));
};
