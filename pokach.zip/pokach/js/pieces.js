/* =====================================================================
   POKACH - pieces.js
   Special-Bausteine und alle 50 Figuren-Definitionen.
   Kunst und Helfer liegen in pieces-art.js (GJ._pk).
   ===================================================================== */
var GJ = globalThis.GJ = globalThis.GJ || {};
(function () {
  const SC = GJ.CONFIG.specials;
  const K = GJ._pk;
  const { lv, inf, vtxt, zug, E, V, sm, eachInRadius, step, tOk, sumV, radiusReach, lineReach, DIRSETS } = K;
  const { KNIGHT, KING, CAMEL, ORTH, DIAG, ALL, ZEBRA, GIRAFFE, ALFIL, DABBABA } = GJ.DIRS;
  const PCS = () => GJ.PIECES;
  const royal = t => !!PCS()[t.type].royal;

  // =====================================================================
  //  Special-Bausteine
  // =====================================================================
  const T = {};

  // Schuss: trifft eine gegnerische Figur in einer Linie.
  // o: { dirs:'all'|'orth'|..., jump:true (ignoriert Blockaden), proj:'arrow'|'fire'|'stone'|'star'|'beam', style }
  T.shot = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: o.anim || 'projectile', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, min = S.min || 1, max = lv(S.max || S.range, l), mv = S.maxValue ? lv(S.maxValue, l) : null;
        const H = S.hits ? lv(S.hits, l) : 1, splash = S.splash ? lv(S.splash, l) : false;
        for (const d of DIRSETS[o.dirs](c)) {
          if (o.jump) {
            for (let k = min; k <= max; k++) {
              const s = step(sq, d, k);
              if (s < 0) break;
              const t = st.board[s];
              if (!tOk(t, c, mv)) continue;
              const caps = [s];
              if (splash) eachInRadius(s, 1, s2 => { const t2 = st.board[s2]; if (tOk(t2, c, 1.8) && PCS()[t2.type].cls === 'bauer') caps.push(s2); });
              out.push(sm(st, sq, p, { picks: [s], caps, affects: caps.slice(), data: { main: s, end: s, proj: o.proj }, gain: sumV(st, caps) }));
            }
          } else {
            const hits = []; let end = sq;
            for (let k = 1; k <= max; k++) {
              const s = step(sq, d, k);
              if (s < 0) break;
              end = s;
              const t = st.board[s];
              if (!t) continue;
              if (k < min || !tOk(t, c, mv)) break;
              hits.push(s);
              if (hits.length >= H) break;
            }
            if (hits.length) out.push(sm(st, sq, p, { picks: [hits[0]], caps: hits, affects: hits.slice(), data: { main: hits[0], end, proj: o.proj }, gain: sumV(st, hits) }));
          }
        }
      },
      apply(st, m, fx) { for (const s of m.caps) E().capture(st, s, fx, o.style || 'burn'); },
      reach(l) { return lineReach(DIRSETS[o.dirs]('w'), S.min || 1, lv(S.max || S.range, l)); }
    };
  };

  // Lähmung: friert eine gegnerische Figur in einer Linie ein
  T.stun = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: o.anim || 'projectile', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, min = S.min || 1, max = lv(S.max || S.range, l), mv = S.maxValue ? lv(S.maxValue, l) : null, dur = lv(S.dur, l);
        for (const d of DIRSETS[o.dirs](c)) {
          for (let k = 1; k <= max; k++) {
            const s = step(sq, d, k);
            if (s < 0) break;
            const t = st.board[s];
            if (!t) continue;
            if (k >= min && tOk(t, c, mv) && !(t.frozen >= dur)) out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { dur, main: s, end: s, proj: o.proj || 'ice' }, gain: V(t.type) * 0.3 * dur }));
            if (!o.jump) break;
          }
        }
      },
      apply(st, m, fx) { for (const s of m.affects) E().freeze(st, s, m.data.dur, fx); },
      reach(l) { return lineReach(DIRSETS[o.dirs]('w'), S.min || 1, lv(S.max || S.range, l)); }
    };
  };

  // Frost-Welle: alle Gegner im Radius eingefroren
  T.nova = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: o.anim || 'frost', desc: o.desc, noInCheck: o.noInCheck,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), dur = lv(S.dur, l), aff = [];
        eachInRadius(sq, R, s => { const t = st.board[s]; if (tOk(t, c)) aff.push(s); });
        if (aff.length) out.push(sm(st, sq, p, { affects: aff, data: { radius: R, dur }, gain: sumV(st, aff) * 0.25 * dur }));
      },
      apply(st, m, fx) { for (const s of m.affects) E().freeze(st, s, m.data.dur, fx); },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // Schutzschild: eigene Figuren im Radius erhalten Schild (optional entfrostet)
  T.aura = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: o.anim || 'bulwark', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), dur = lv(S.dur, l), aff = [];
        if (!royal(p)) aff.push(sq);
        let frozen = 0;
        eachInRadius(sq, R, s => { const t = st.board[s]; if (t && t.color === c && (!royal(t) || (o.cleanse && t.frozen))) { aff.push(s); if (t.frozen) frozen++; } });
        if (aff.length > (o.minCount || 1) - 1) out.push(sm(st, sq, p, { affects: aff, data: { radius: R, dur, cleanse: !!o.cleanse }, gain: aff.length * 0.15 + frozen * 0.6 }));
      },
      apply(st, m, fx) {
        const e = E();
        for (const s of m.affects) { if (m.data.cleanse) e.unfreeze(st, s, fx); e.shieldPiece(st, s, m.data.dur, fx); }
      },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // Teleport: auf ein leeres Feld im Radius
  T.blink = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'teleport', desc: o.desc, noInCheck: o.noInCheck,
      generate(st, sq, p, l, out) {
        const R = lv(S.radius, l);
        eachInRadius(sq, R, s => { if (!st.board[s] && E().cheb(sq, s) >= 2) E().pushPromoVariants(st, p.color, s, sm(st, sq, p, { to: s, picks: [s], gain: 0 }), out, PCS()[p.type].cls === 'bauer'); });
      },
      apply(st, m, fx) { E().movePiece(st, m.from, m.to, fx, 'blink'); if (m.promo) E().promote(st, m.to, m.promo, fx); },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // Sprungangriff: fliegt in den Radius und darf dort schlagen
  T.pounce = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'dive', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), mv = lv(S.maxValue, l), fz = S.freezePawns ? lv(S.freezePawns, l) : false;
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!t) { if (E().cheb(sq, s) >= 2) out.push(sm(st, sq, p, { to: s, picks: [s], data: { freeze: fz }, gain: 0 })); }
          else if (tOk(t, c, mv)) out.push(sm(st, sq, p, { to: s, picks: [s], caps: [s], affects: [s], data: { freeze: fz }, gain: V(t.type) }));
        });
      },
      apply(st, m, fx) {
        const e = E(), c = st.board[m.from].color;
        if (m.caps.length) e.capture(st, m.caps[0], fx);
        e.movePiece(st, m.from, m.to, fx, 'fly');
        if (m.data.freeze) eachInRadius(m.to, 1, s => { const t = st.board[s]; if (tOk(t, c) && PCS()[t.type].cls === 'bauer') e.freeze(st, s, 1, fx); });
      },
      reach(l) { return radiusReach(Math.min(3, lv(S.radius, l))); }
    };
  };

  // Wegstoßen: angrenzende Gegner werden weggeschoben, optional zerquetscht
  T.push = function (key, o) {
    const S = SC[key];
    const dirs = o.orth ? ORTH : KING;
    return {
      name: o.name, anim: o.anim || 'sandstorm', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, aff = [];
        for (const d of dirs) { const s = step(sq, d, 1); if (s >= 0 && tOk(st.board[s], c)) aff.push(s); }
        if (aff.length) out.push(sm(st, sq, p, { affects: aff, data: { dist: lv(S.dist, l), crush: lv(S.crush, l), orth: !!o.orth }, gain: aff.length * 0.2 + (lv(S.crush, l) ? sumV(st, aff) * 0.4 : 0) }));
      },
      apply(st, m, fx) {
        const e = E(), c = st.board[m.from].color;
        for (const d of (m.data.orth ? ORTH : KING)) {
          const s = step(m.from, d, 1);
          if (s < 0) continue;
          const t = st.board[s];
          if (!t || !tOk(t, c)) continue;
          let pos = s, blocked = false;
          for (let k = 1; k <= m.data.dist; k++) {
            const n = step(pos, d, 1);
            if (n < 0 || st.board[n]) { blocked = true; break; }
            pos = n;
          }
          if (pos !== s) e.movePiece(st, s, pos, fx, 'push');
          if (blocked && m.data.crush) e.capture(st, pos, fx, 'crush');
          else e.autoPromote(st, pos, fx);
        }
      },
      reach() { return dirs.slice(); }
    };
  };

  // Platztausch mit eigener Figur
  T.swapAlly = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'swap', desc: o.desc, noInCheck: o.noInCheck,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), sh = S.shield ? lv(S.shield, l) : (S.shieldSwapped ? lv(S.shieldSwapped, l) : 0);
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!t || t.color !== c || royal(t) || t.type === p.type) return;
          // Bauern-Klasse darf nicht auf die eigene oder gegnerische Grundreihe getauscht werden
          if (PCS()[t.type].cls === 'bauer' && ((sq >> 3) === 0 || (sq >> 3) === 7)) return;
          if (PCS()[p.type].cls === 'bauer' && ((s >> 3) === 0 || (s >> 3) === 7)) return;
          out.push(sm(st, sq, p, { to: s, picks: [s], affects: [s], data: { shield: sh }, gain: 0.05 }));
        });
      },
      apply(st, m, fx) { E().swapPieces(st, m.from, m.to, m.data.shield, fx); },
      reach(l) { return radiusReach(Math.min(3, lv(S.radius, l))); }
    };
  };

  // Platztausch mit angrenzendem Gegner
  T.swapEnemy = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'swap', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), mv = lv(S.maxValue, l);
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c, mv)) return;
          if (PCS()[t.type].cls === 'bauer' && ((sq >> 3) === 0 || (sq >> 3) === 7)) return;
          out.push(sm(st, sq, p, { to: s, picks: [s], affects: [s], data: {}, gain: 0.1 }));
        });
      },
      apply(st, m, fx) { E().swapPieces(st, m.from, m.to, 0, fx); },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // Heranziehen: Gegner in einer Linie wird zum Ziehenden gezogen
  T.pull = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'pull', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.range, l), n = lv(S.steps, l), mv = lv(S.maxValue, l);
        for (const d of ALL) {
          for (let k = 1; k <= R; k++) {
            const s = step(sq, d, k);
            if (s < 0) break;
            const t = st.board[s];
            if (!t) continue;
            if (k >= 2 && tOk(t, c, mv)) {
              const back = [-d[0], -d[1]];
              let pos = s;
              for (let i = 0; i < n; i++) { const q = step(pos, back, 1); if (q < 0 || q === sq || st.board[q]) break; pos = q; }
              if (pos !== s) out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { dest: pos }, gain: 0.3 }));
            }
            break;
          }
        }
      },
      apply(st, m, fx) { const e = E(); const s = m.affects[0]; e.movePiece(st, s, m.data.dest, fx, 'pull'); e.autoPromote(st, m.data.dest, fx); },
      reach(l) { return lineReach(ALL, 2, lv(S.range, l)); }
    };
  };

  // Verstärkung: erschafft eigene Bauern auf freien Nachbarfeldern (gerade)
  T.spawn = function (key, o) {
    const S = SC[key];
    const cand = (st, sq) => {
      const r = [];
      for (const d of ORTH) { const s = step(sq, d, 1); if (s >= 0 && !st.board[s] && (s >> 3) !== 0 && (s >> 3) !== 7) r.push(s); }
      return r;
    };
    return {
      name: o.name, anim: 'spawn', desc: o.desc,
      generate(st, sq, p, l, out) {
        const n = lv(S.count, l), sh = lv(S.shield, l), cs = cand(st, sq);
        for (const s of cs) {
          const list = [s].concat(cs.filter(q => q !== s)).slice(0, n);
          out.push(sm(st, sq, p, { picks: [s], affects: list, data: { type: 'bauer', shield: sh }, gain: list.length * 0.9 }));
        }
      },
      apply(st, m, fx) {
        const e = E(), c = st.board[m.from].color;
        for (const s of m.affects) { e.spawnPiece(st, s, m.data.type, c, fx); if (m.data.shield) e.shieldPiece(st, s, m.data.shield, fx); }
      },
      reach() { return ORTH.slice(); }
    };
  };

  // Ansturm: zieht gerade bis zur ersten gegnerischen Figur und schlägt sie
  T.charge = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'ram', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.range, l), mv = lv(S.maxValue, l);
        for (const d of DIRSETS[o.dirs](c)) {
          for (let k = 1; k <= R; k++) {
            const s = step(sq, d, k);
            if (s < 0) break;
            const t = st.board[s];
            if (!t) continue;
            if (tOk(t, c, mv)) E().pushPromoVariants(st, c, s, sm(st, sq, p, { to: s, picks: [s], caps: [s], affects: [s], gain: V(t.type) }), out, PCS()[p.type].cls === 'bauer');
            break;
          }
        }
      },
      apply(st, m, fx) { const e = E(); e.capture(st, m.caps[0], fx, 'knock'); e.movePiece(st, m.from, m.to, fx); if (m.promo) e.promote(st, m.to, m.promo, fx); },
      reach(l) { return lineReach(DIRSETS[o.dirs]('w'), 1, lv(S.range, l)); }
    };
  };

  // Abstufung: gegnerische Figur wird eine Klasse schwächer
  const DEMOTE = { dame: 'turm', turm: 'laeufer', laeufer: 'springer', springer: 'bauer' };
  T.demote = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'polymorph', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), mv = lv(S.maxValue, l);
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c, mv)) return;
          const to = DEMOTE[PCS()[t.type].cls];
          if (!to) return;
          if (to === 'bauer' && ((s >> 3) === 0 || (s >> 3) === 7)) return;
          if (V(to) >= V(t.type)) return;
          out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { type: to, freeze: 0 }, gain: V(t.type) - V(to) }));
        });
      },
      apply(st, m, fx) { E().transformPiece(st, m.affects[0], m.data.type, m.data.freeze, fx); },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // Linienfrost: alle Gegner in geraden Linien (durchdringt Figuren)
  T.lineFreeze = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'tide', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.range, l), aff = [];
        for (const d of ORTH) for (let k = 1; k <= R; k++) { const s = step(sq, d, k); if (s < 0) break; if (tOk(st.board[s], c)) aff.push(s); }
        if (aff.length) out.push(sm(st, sq, p, { affects: aff, data: { dur: lv(S.dur, l), range: R }, gain: sumV(st, aff) * 0.25 }));
      },
      apply(st, m, fx) { for (const s of m.affects) E().freeze(st, s, m.data.dur, fx); },
      reach(l) { return lineReach(ORTH, 1, lv(S.range, l)); }
    };
  };

  // Stoß aus dem Stand: schlägt per Sprungmuster, ohne sich zu bewegen
  T.strike = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'projectile', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, mv = lv(S.maxValue, l);
        for (const v of o.vecs) { const s = step(sq, v, 1); if (s >= 0 && tOk(st.board[s], c, mv)) out.push(sm(st, sq, p, { picks: [s], caps: [s], affects: [s], data: { main: s, end: s, proj: o.proj || 'star' }, gain: V(st.board[s].type) })); }
      },
      apply(st, m, fx) { E().capture(st, m.caps[0], fx, 'slash'); },
      reach() { return o.vecs.slice(); }
    };
  };

  // Feuerschwinge: angrenzende Bauern-Klasse verbrennt, optional Frost im Radius
  T.sweep = function (key, o) {
    const S = SC[key];
    return {
      name: o.name, anim: 'blades', desc: o.desc,
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(S.radius, l), fz = lv(S.freeze, l), caps = [], aff = [];
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c)) return;
          if (E().cheb(sq, s) === 1 && PCS()[t.type].cls === 'bauer') caps.push(s);
          else if (fz) aff.push(s);
        });
        if (caps.length || aff.length) out.push(sm(st, sq, p, { caps, affects: caps.concat(aff), data: { radius: R, dur: 1 }, gain: sumV(st, caps) + sumV(st, aff) * 0.2 }));
      },
      apply(st, m, fx) { const e = E(); for (const s of m.affects) { if (m.caps.includes(s)) e.capture(st, s, fx, 'burn'); else e.freeze(st, s, 1, fx); } },
      reach(l) { return radiusReach(lv(S.radius, l)); }
    };
  };

  // =====================================================================
  //  Figuren
  // =====================================================================
  const P = {};
  function def(key, o) {
    o.key = key;
    o.svg = (c, m) => K.svgFor(key, c, m);
    P[key] = o;
  }

  // ---------- Standardfiguren ----------
  def('bauer', {
    name: 'Bauer', abbr: '', cls: 'bauer', rarity: 'standard', value: 1, cost: 1,
    move: { pawn: {} },
    moveText: 'Zieht 1 Feld vorwärts (von der 2. Reihe aus auch 2), schlägt diagonal vorwärts. En passant und Umwandlung.',
    special: {
      name: 'Traktor-Rammstoß', anim: 'tractor',
      desc: () => {
        const s = SC.bauer;
        return [
          `Fährt mit dem Traktor bis zu ${s.range[0]} Felder geradeaus und mäht die erste gegnerische Figur um (${vtxt(s.maxValue[0])}).`,
          `Reichweite ${s.range[1]} Felder.`,
          `Reichweite ${s.range[2]} Felder, ${vtxt(s.maxValue[2])}, nach dem ersten Treffer fährt er weiter und kann eine zweite Figur umwemsen.`
        ];
      },
      generate(st, sq, p, l, out) {
        const e = E(), c = p.color, f = e.fwd(c), R = lv(SC.bauer.range, l), second = lv(SC.bauer.secondHit, l), mv = lv(SC.bauer.maxValue, l);
        const caps = [];
        for (let k = 1; k <= R; k++) {
          const s = step(sq, [0, f], k);
          if (s < 0) break;
          const t = st.board[s];
          if (t) {
            if (!tOk(t, c, mv)) break;
            caps.push(s);
          }
          if (caps.length) e.pushPromoVariants(st, c, s, sm(st, sq, p, { to: s, picks: [s], caps: caps.slice(), affects: caps.slice(), gain: sumV(st, caps) }), out, true);
          if (t && !(second && caps.length < 2)) break;
          if (caps.length >= 2) break;
        }
      },
      apply(st, m, fx) {
        const e = E();
        for (const s of m.caps) e.capture(st, s, fx, 'knock');
        e.movePiece(st, m.from, m.to, fx);
        if (m.promo) e.promote(st, m.to, m.promo, fx);
      },
      reach(l) { const o = []; for (let k = 1; k <= lv(SC.bauer.range, l); k++) o.push([0, k]); return o; }
    }
  });

  def('springer', {
    name: 'Springer', abbr: 'S', cls: 'springer', rarity: 'standard', value: 3, cost: 3,
    move: { leaps: KNIGHT },
    moveText: 'Springt im L: 2 Felder in eine Richtung, 1 Feld zur Seite. Springt über Figuren.',
    special: {
      name: 'Doppelsprung', anim: 'doublejump',
      desc: () => [
        'Zwei Springersprünge in einem Zug. Der erste muss auf ein leeres Feld, der zweite darf schlagen.',
        'Beide Sprünge dürfen schlagen (insgesamt höchstens 1 Schlag).',
        'Bis zu drei Sprünge, maximal 2 Schläge.'
      ],
      generate(st, sq, p, l, out) {
        const c = p.color, S = SC.springer;
        const maxJ = lv(S.jumps, l), firstCap = lv(S.firstCanCapture, l), maxCaps = lv(S.maxCaps, l);
        const seen = new Set();
        const rec = (pos, path, caps) => {
          for (const v of KNIGHT) {
            const to = step(pos, v, 1);
            if (to < 0) continue;
            const occ = (to === sq || caps.includes(to)) ? null : st.board[to];
            let ncaps = caps;
            if (occ) {
              if (!tOk(occ, c)) continue;
              if (path.length === 0 && !firstCap) continue;
              if (caps.length >= maxCaps) continue;
              ncaps = caps.concat(to);
            }
            const np = path.concat(to);
            const key = np.join('.');
            if (np.length >= 2 && to !== sq && !seen.has(key)) { seen.add(key); out.push(sm(st, sq, p, { to, picks: np, caps: ncaps, affects: ncaps.slice(), gain: sumV(st, ncaps) })); }
            if (np.length < maxJ) rec(to, np, ncaps);
          }
        };
        rec(sq, [], []);
      },
      apply(st, m, fx) {
        const e = E();
        for (const s of m.picks) if (m.caps.includes(s)) e.capture(st, s, fx);
        e.movePiece(st, m.from, m.to, fx);
      },
      reach() { return KNIGHT.slice(); }
    }
  });

  def('laeufer', {
    name: 'Läufer', abbr: 'L', cls: 'laeufer', rarity: 'standard', value: 3.25, cost: 3,
    move: { rides: { dirs: DIAG, max: 7 } },
    moveText: 'Zieht beliebig weit diagonal.',
    special: T.shot('laeufer', {
      name: 'Heiliger Strahl', anim: 'beam', dirs: 'diag', style: 'dissolve',
      desc: () => { const s = SC.laeufer; return [
        `Bleibt stehen und feuert einen Lichtstrahl diagonal. Zerstört die erste gegnerische Figur innerhalb von ${s.range[0]} Feldern.`,
        `Reichweite ${inf(s.range[1])}.`,
        `Reichweite ${inf(s.range[2])}, der Strahl durchdringt und trifft bis zu ${s.hits[2]} Figuren.`]; }
    })
  });

  def('turm', {
    name: 'Turm', abbr: 'T', cls: 'turm', rarity: 'standard', value: 5, cost: 5,
    move: { rides: { dirs: ORTH, max: 7 } },
    moveText: 'Zieht beliebig weit gerade (waagrecht oder senkrecht). Rochade.',
    special: {
      name: 'Rammbock', anim: 'ram',
      desc: () => { const s = SC.turm; return [
        `Fährt bis zu ${s.range[0]} Felder gerade und rammt die erste gegnerische Figur auf dem Weg weg.`,
        `Reichweite ${s.range[1]} Felder.`,
        `Reichweite ${s.range[2]} Felder, rammt bis zu ${s.maxCaps[2]} Figuren hintereinander.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(SC.turm.range, l), N = lv(SC.turm.maxCaps, l);
        for (const d of ORTH) {
          const caps = [];
          for (let k = 1; k <= R; k++) {
            const s = step(sq, d, k);
            if (s < 0) break;
            const t = st.board[s];
            if (t) {
              if (!tOk(t, c) || caps.length >= N) break;
              caps.push(s);
            }
            if (caps.length && t) out.push(sm(st, sq, p, { to: s, picks: [s], caps: caps.slice(), affects: caps.slice(), gain: sumV(st, caps) }));
          }
        }
      },
      apply(st, m, fx) { const e = E(); for (const s of m.caps) e.capture(st, s, fx, 'knock'); e.movePiece(st, m.from, m.to, fx); },
      reach(l) { return lineReach(ORTH, 1, lv(SC.turm.range, l)); }
    }
  });

  def('dame', {
    name: 'Dame', abbr: 'D', cls: 'dame', rarity: 'standard', value: 9, cost: 9,
    move: { rides: { dirs: ALL, max: 7 } },
    moveText: 'Zieht beliebig weit gerade oder diagonal.',
    special: T.nova('dame', {
      name: 'Frostnova',
      desc: () => { const s = SC.dame; return [
        `Bleibt stehen. Alle gegnerischen Figuren im Radius ${s.radius[0]} werden ${zug(s.dur[0])} eingefroren.`,
        `Radius ${s.radius[1]}, ${zug(s.dur[1])}.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  def('koenig', {
    name: 'König', abbr: 'K', cls: 'koenig', rarity: 'standard', value: 0, cost: 0, royal: true,
    move: { leaps: KING },
    moveText: 'Zieht 1 Feld in jede Richtung. Rochade (tippe danach auf g1/c1 oder auf den Turm). Darf nie ins Schach ziehen.',
    special: T.swapAlly('koenig', {
      name: 'Königstausch', noInCheck: true,
      desc: () => { const s = SC.koenig; return [
        `Tauscht den Platz mit einer eigenen Figur im Radius ${s.radius[0]}. Nicht möglich, wenn der König im Schach steht.`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, die getauschte Figur bekommt 1 Zug Schild.`]; }
    })
  });

  // ---------- Bisherige Sonderfiguren (abgeschwächt) ----------
  def('spaeher', {
    name: 'Späher', abbr: 'Sp', cls: 'bauer', rarity: 'gewoehnlich', value: 1.3, cost: 2,
    move: { pawn: { sideStep: true } },
    moveText: 'Wie ein Bauer, darf zusätzlich 1 Feld seitwärts auf ein leeres Feld ziehen (ohne Schlagen).',
    special: T.aura('spaeher', {
      name: 'Rauchbombe', anim: 'smoke',
      desc: () => { const s = SC.spaeher; return [
        `Alle eigenen Figuren im Radius ${s.radius[0]} (inkl. Späher) erhalten ${zug(s.dur[0])} Schild.`,
        `Radius ${s.radius[1]}, ${zug(s.dur[1])} Schild.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])} Schild.`]; }
    })
  });

  def('lanzentraeger', {
    name: 'Lanzenträger', abbr: 'La', cls: 'bauer', rarity: 'selten', value: 1.4, cost: 2,
    move: { pawn: { straightCapture: true } },
    moveText: 'Wie ein Bauer, schlägt zusätzlich 1 Feld gerade vorwärts.',
    special: {
      name: 'Lanzenwurf', anim: 'projectile',
      desc: () => { const s = SC.lanzentraeger; return [
        `Bleibt stehen und wirft die Lanze genau ${s.minDist} Felder geradeaus (${vtxt(s.maxValue[0])}, überspringt alles dazwischen).`,
        `Entfernung ${s.minDist} bis ${s.maxDist[1]}, gerade oder diagonal vorwärts, ${vtxt(s.maxValue[1])}.`,
        `Entfernung ${s.minDist} bis ${s.maxDist[2]}, ${vtxt(s.maxValue[2])}.`]; },
      generate(st, sq, p, l, out) {
        const e = E(), c = p.color, f = e.fwd(c), S = SC.lanzentraeger, mv = lv(S.maxValue, l);
        const dirs = lv(S.diag, l) ? [[0, f], [-1, f], [1, f]] : [[0, f]];
        for (const d of dirs) for (let k = S.minDist; k <= lv(S.maxDist, l); k++) {
          const s = step(sq, d, k);
          if (s < 0) break;
          if (tOk(st.board[s], c, mv)) out.push(sm(st, sq, p, { picks: [s], caps: [s], affects: [s], data: { main: s, end: s, proj: 'lance' }, gain: V(st.board[s].type) }));
        }
      },
      apply(st, m, fx) { E().capture(st, m.caps[0], fx); },
      reach(l) { const S = SC.lanzentraeger; return lineReach(lv(S.diag, l) ? [[0, 1], [-1, 1], [1, 1]] : [[0, 1]], S.minDist, lv(S.maxDist, l)); }
    }
  });

  def('kamelreiter', {
    name: 'Kamelreiter', abbr: 'Ka', cls: 'springer', rarity: 'gewoehnlich', value: 2.3, cost: 2,
    move: { leaps: CAMEL },
    moveText: 'Springt 3 Felder in eine Richtung und 1 zur Seite. Springt über Figuren.',
    special: T.push('kamelreiter', {
      name: 'Wüstensturm',
      desc: () => { const s = SC.kamelreiter; return [
        `Schiebt alle angrenzenden gegnerischen Figuren ${s.dist[0]} Feld vom Kamel weg.`,
        `Schiebt bis zu ${s.dist[1]} Felder weit.`,
        `Schiebt ${s.dist[2]} Felder, wer gegen eine Figur oder den Rand prallt, wird zerstört.`]; }
    })
  });

  def('greif', {
    name: 'Greif', abbr: 'Gr', cls: 'springer', rarity: 'episch', value: 4.5, cost: 5,
    move: { leaps: KNIGHT.concat(ORTH) },
    moveText: 'Springt wie ein Springer oder zieht 1 Feld gerade.',
    special: T.pounce('greif', {
      name: 'Sturzflug',
      desc: () => { const s = SC.greif; return [
        `Fliegt auf ein Feld im Radius ${s.radius[0]} (ignoriert Blockaden) und darf dort schlagen (${vtxt(s.maxValue[0])}).`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, ${vtxt(s.maxValue[2])}, gegnerische Bauern-Klasse neben dem Landefeld wird 1 Zug eingefroren.`]; }
    })
  });

  def('moench', {
    name: 'Mönch', abbr: 'Mö', cls: 'laeufer', rarity: 'gewoehnlich', value: 3.3, cost: 3,
    move: { rides: { dirs: DIAG, max: 3 }, leaps: ORTH },
    moveText: 'Zieht diagonal bis zu 3 Felder oder 1 Feld gerade.',
    special: {
      name: 'Bekehrung', anim: 'convert',
      desc: () => [
        'Eine angrenzende gegnerische Figur der Bauern-Klasse wechselt auf deine Seite.',
        'Wie Stufe 1, die bekehrte Figur bekommt 1 Zug Schild.',
        `Eine angrenzende gegnerische Figur mit Wert bis ${SC.moench.maxValue[2]} wechselt die Seite.`
      ],
      generate(st, sq, p, l, out) {
        const c = p.color, S = SC.moench, R = lv(S.radius, l), pawnOnly = lv(S.pawnOnly, l), maxV = lv(S.maxValue, l);
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c, maxV)) return;
          if (pawnOnly && PCS()[t.type].cls !== 'bauer') return;
          out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { shield: l === 2 ? 1 : 0 }, gain: V(t.type) * 2 }));
        });
      },
      apply(st, m, fx) { const e = E(); e.convertPiece(st, m.affects[0], st.board[m.from].color, fx); if (m.data.shield && st.board[m.affects[0]]) e.shieldPiece(st, m.affects[0], m.data.shield, fx); },
      reach(l) { return radiusReach(lv(SC.moench.radius, l)); }
    }
  });

  def('erzmagier', {
    name: 'Erzmagier', abbr: 'Em', cls: 'laeufer', rarity: 'episch', value: 8.5, cost: 9,
    move: { rides: { dirs: DIAG, max: 7 }, leaps: KNIGHT },
    moveText: 'Zieht wie Läufer oder springt wie Springer.',
    special: {
      name: 'Kettenblitz', anim: 'bolt',
      desc: () => { const s = SC.erzmagier; return [
        `Zerstört eine gegnerische Figur im Radius ${s.radius[0]} (${vtxt(s.maxValue[0])}).`,
        `Radius ${s.radius[1]}, ${vtxt(s.maxValue[1])}.`,
        `Radius ${s.radius[2]}, der Blitz springt zusätzlich auf eine angrenzende gegnerische Bauern-Klasse über.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(SC.erzmagier.radius, l), chain = lv(SC.erzmagier.chain, l), mv = lv(SC.erzmagier.maxValue, l);
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c, mv)) return;
          const caps = [s];
          if (chain) {
            let best = -1;
            eachInRadius(s, 1, s2 => { const t2 = st.board[s2]; if (best < 0 && tOk(t2, c) && PCS()[t2.type].cls === 'bauer') best = s2; });
            if (best >= 0) caps.push(best);
          }
          out.push(sm(st, sq, p, { picks: [s], caps, affects: caps.slice(), gain: sumV(st, caps) }));
        });
      },
      apply(st, m, fx) { for (const s of m.caps) E().capture(st, s, fx, 'burn'); },
      reach(l) { return radiusReach(lv(SC.erzmagier.radius, l)); }
    }
  });

  def('golem', {
    name: 'Golem', abbr: 'Go', cls: 'turm', rarity: 'gewoehnlich', value: 4, cost: 4,
    move: { rides: { dirs: ORTH, max: 2 }, leaps: KING },
    moveText: 'Zieht gerade bis zu 2 Felder oder 1 Feld in jede Richtung. Kann rochieren.',
    special: {
      name: 'Erdstampfer', anim: 'stomp',
      desc: () => { const s = SC.golem; return [
        `Angrenzende gegnerische Figuren werden ${zug(s.dur[0])} eingefroren.`,
        'Zusätzlich wird angrenzende gegnerische Bauern-Klasse zerstört.',
        `Einfrieren im Radius ${s.freezeRadius[2]}, Zerstören weiter nur direkt daneben.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, S = SC.golem, R = lv(S.freezeRadius, l), cr = lv(S.crushRadius, l); const aff = [], caps = [];
        eachInRadius(sq, R, s => {
          const t = st.board[s];
          if (!tOk(t, c)) return;
          aff.push(s);
          if (E().cheb(sq, s) <= cr && PCS()[t.type].cls === 'bauer') caps.push(s);
        });
        if (aff.length) out.push(sm(st, sq, p, { caps, affects: aff, data: { dur: lv(S.dur, l), radius: R }, gain: sumV(st, caps) + (aff.length - caps.length) * 0.4 }));
      },
      apply(st, m, fx) {
        const e = E();
        for (const s of m.affects) { if (m.caps.includes(s)) e.capture(st, s, fx, 'crush'); else e.freeze(st, s, m.data.dur, fx); }
      },
      reach(l) { return radiusReach(lv(SC.golem.freezeRadius, l)); }
    }
  });

  def('katapult', {
    name: 'Katapult', abbr: 'Kt', cls: 'turm', rarity: 'selten', value: 4.5, cost: 6,
    move: { cannon: true },
    moveText: 'Zieht gerade wie ein Turm, aber nur auf leere Felder. Schlägt nur, indem es genau eine Figur überspringt. Kann rochieren.',
    special: {
      name: 'Feuerball', anim: 'fireball',
      desc: () => { const s = SC.katapult; return [
        `Schießt im Bogen auf eine gegnerische Figur ${s.minDist} bis ${s.maxDist[0]} Felder entfernt (gerade oder diagonal, ignoriert Blockaden, ${vtxt(s.maxValue[0])}).`,
        `Entfernung ${s.minDist} bis ${s.maxDist[1]}.`,
        `Entfernung ${s.minDist} bis ${s.maxDist[2]}, ${vtxt(s.maxValue[2])}, gegnerische Bauern-Klasse neben dem Einschlag wird mitzerstört.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, S = SC.katapult, mx = lv(S.maxDist, l), splash = lv(S.splash, l), mv = lv(S.maxValue, l);
        for (const d of ALL) for (let k = S.minDist; k <= mx; k++) {
          const s = step(sq, d, k);
          if (s < 0) break;
          const t = st.board[s];
          if (!tOk(t, c, mv)) continue;
          const caps = [s];
          if (splash) eachInRadius(s, 1, s2 => { const t2 = st.board[s2]; if (tOk(t2, c) && PCS()[t2.type].cls === 'bauer') caps.push(s2); });
          out.push(sm(st, sq, p, { picks: [s], caps, affects: caps.slice(), data: { main: s }, gain: sumV(st, caps) }));
        }
      },
      apply(st, m, fx) { for (const s of m.caps) E().capture(st, s, fx, 'burn'); },
      reach(l) { const S = SC.katapult; return lineReach(ALL, S.minDist, lv(S.maxDist, l)); }
    }
  });

  def('hexe', {
    name: 'Hexe', abbr: 'He', cls: 'dame', rarity: 'episch', value: 6.5, cost: 7,
    move: { rides: { dirs: ALL, max: 3 } },
    moveText: 'Zieht wie eine Dame, aber höchstens 3 Felder weit.',
    special: {
      name: 'Verwandlung', anim: 'polymorph',
      desc: () => { const s = SC.hexe; return [
        `Verwandelt eine gegnerische Figur in freier Damenlinie (bis ${s.range[0]} Felder, ${vtxt(s.maxValue[0])}) in einen Bauern. Nicht auf Reihe 1 oder 8.`,
        `Reichweite ${s.range[1]}, ${vtxt(s.maxValue[1])}.`,
        `Reichweite ${inf(s.range[2])}, der neue Bauer ist zusätzlich 1 Zug eingefroren.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, R = lv(SC.hexe.range, l), fz = lv(SC.hexe.freeze, l), mv = lv(SC.hexe.maxValue, l);
        for (const d of ALL) for (let k = 1; k <= R; k++) {
          const s = step(sq, d, k);
          if (s < 0) break;
          const t = st.board[s];
          if (!t) continue;
          const r = s >> 3;
          if (tOk(t, c, mv) && PCS()[t.type].cls !== 'bauer' && r !== 0 && r !== 7) out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { freeze: fz, type: 'bauer' }, gain: V(t.type) - 1 }));
          break;
        }
      },
      apply(st, m, fx) { E().transformPiece(st, m.affects[0], 'bauer', m.data.freeze, fx); },
      reach(l) { return lineReach(ALL, 1, lv(SC.hexe.range, l)); }
    }
  });

  def('amazone', {
    name: 'Amazone', abbr: 'Am', cls: 'dame', rarity: 'legendaer', value: 12, cost: 13,
    move: { rides: { dirs: ALL, max: 7 }, leaps: KNIGHT },
    moveText: 'Zieht wie eine Dame oder springt wie ein Springer.',
    special: {
      name: 'Klingenwirbel', anim: 'blades',
      desc: () => { const s = SC.amazone; return [
        `Bleibt stehen und schlägt die wertvollste angrenzende gegnerische Figur.`,
        `Bis zu ${s.max[1]} angrenzende Figuren.`,
        `Bis zu ${s.max[2]} Figuren, die Amazone bekommt danach 1 Zug Schild.`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, N = lv(SC.amazone.max, l); const cand = [];
        eachInRadius(sq, 1, s => { if (tOk(st.board[s], c)) cand.push(s); });
        if (!cand.length) return;
        cand.sort((a, b) => V(st.board[b].type) - V(st.board[a].type) || a - b);
        const caps = cand.slice(0, N);
        out.push(sm(st, sq, p, { caps, affects: caps.slice(), data: { shield: l >= 3 ? 1 : 0 }, gain: sumV(st, caps) }));
      },
      apply(st, m, fx) { const e = E(); for (const s of m.caps) e.capture(st, s, fx, 'slash'); if (m.data.shield) e.shieldPiece(st, m.from, 1, fx); },
      reach() { return KING.slice(); }
    }
  });

  def('waechter', {
    name: 'Wächter', abbr: 'Wä', cls: 'koenig', rarity: 'selten', value: 0, cost: 2, royal: true,
    move: { leaps: KING, extra: 'waechter' },
    moveText: 'Wie ein König, darf zusätzlich 2 Felder gerade auf ein leeres Feld ziehen, wenn das Feld dazwischen leer und nicht angegriffen ist.',
    special: T.aura('waechter', {
      name: 'Bollwerk',
      desc: () => { const s = SC.waechter; return [
        `Alle eigenen Figuren im Radius ${s.radius[0]} erhalten ${zug(s.dur[0])} Schild.`,
        `Radius ${s.radius[1]}, ${zug(s.dur[1])}.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  def('kaiser', {
    name: 'Kaiser', abbr: 'Ks', cls: 'koenig', rarity: 'legendaer', value: 0, cost: 4, royal: true,
    move: { leaps: KING.concat(DABBABA) },
    moveText: 'Wie ein König, darf zusätzlich genau 2 Felder gerade springen.',
    special: {
      name: 'Ruf der Legion', anim: 'revive',
      desc: () => { const s = SC.kaiser; return [
        'Belebt eine eigene geschlagene Figur der Bauern-Klasse wieder (auf Reihe 2). Sie ist 1 Zug eingefroren.',
        `Belebt eine Figur mit Wert bis ${s.maxValue[1]} wieder (Grundreihe, Bauern auf Reihe 2), 1 Zug eingefroren.`,
        `Wert bis ${s.maxValue[2]} (keine Dame).`]; },
      generate(st, sq, p, l, out) {
        const c = p.color, maxV = lv(SC.kaiser.maxValue, l);
        const types = [...new Set(st.captured[c])].filter(t => PCS()[t] && !PCS()[t].royal && PCS()[t].value <= maxV);
        for (const type of types) {
          const pawn = PCS()[type].cls === 'bauer';
          const row = pawn ? (c === 'w' ? 1 : 6) : (c === 'w' ? 0 : 7);
          for (let f = 0; f < 8; f++) {
            const s = row * 8 + f;
            if (!st.board[s]) out.push(sm(st, sq, p, { picks: [s], affects: [s], data: { type }, label: PCS()[type].name, gain: PCS()[type].value * 0.9 }));
          }
        }
      },
      apply(st, m, fx) { const e = E(); e.revivePiece(st, m.picks[0], st.board[m.from].color, m.data.type, fx); e.freeze(st, m.picks[0], 1, fx); },
      reach() { return []; }
    }
  });

  // ---------- Neue Figuren: Bauern-Klasse ----------
  def('schleicher', {
    name: 'Schleicher', abbr: 'Sl', cls: 'bauer', rarity: 'gewoehnlich', value: 1, cost: 1,
    move: { pawn: { berolina: true } },
    moveText: 'Zieht 1 Feld schräg vorwärts und schlägt 1 Feld gerade vorwärts (umgekehrter Bauer). Kein Doppelschritt.',
    special: T.stun('schleicher', {
      name: 'Blendpulver', dirs: 'fwd', jump: false, proj: 'ice',
      desc: () => { const s = SC.schleicher; return [
        `Wirft Blendpulver geradeaus: die erste gegnerische Figur innerhalb von ${s.max[0]} Feldern ist ${zug(s.dur[0])} eingefroren.`,
        `Reichweite ${s.max[1]}.`,
        `Reichweite ${s.max[2]}, ${zug(s.dur[2])} eingefroren.`]; }
    })
  });

  def('fahnentraeger', {
    name: 'Fahnenträger', abbr: 'Fa', cls: 'bauer', rarity: 'gewoehnlich', value: 1, cost: 2,
    move: { pawn: {} },
    moveText: 'Zieht und schlägt wie ein Bauer.',
    special: T.spawn('fahnentraeger', {
      name: 'Sammelruf',
      desc: () => { const s = SC.fahnentraeger; return [
        'Ruft einen neuen Bauern auf ein freies Feld direkt neben, vor oder hinter den Fahnenträger.',
        'Der neue Bauer bekommt 1 Zug Schild.',
        `Ruft ${s.count[2]} Bauern, beide mit 1 Zug Schild.`]; }
    })
  });

  def('bogenschuetze', {
    name: 'Bogenschütze', abbr: 'Bo', cls: 'bauer', rarity: 'selten', value: 1.1, cost: 2,
    move: { pawn: {} },
    moveText: 'Zieht und schlägt wie ein Bauer.',
    special: T.shot('bogenschuetze', {
      name: 'Pfeilhagel', dirs: 'fwdDiag', jump: true, proj: 'arrow', style: 'knock',
      desc: () => { const s = SC.bogenschuetze; return [
        `Schießt schräg vorwärts über alles hinweg: trifft eine gegnerische Figur ${s.min} bis ${s.max[0]} Felder entfernt (${vtxt(s.maxValue[0])}).`,
        `Entfernung ${s.min} bis ${s.max[1]}.`,
        `Entfernung ${s.min} bis ${s.max[2]}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('grenadier', {
    name: 'Grenadier', abbr: 'Gn', cls: 'bauer', rarity: 'episch', value: 1.2, cost: 3,
    move: { pawn: {} },
    moveText: 'Zieht und schlägt wie ein Bauer.',
    special: T.shot('grenadier', {
      name: 'Granate', dirs: 'fwd3', jump: true, proj: 'fire', style: 'burn',
      desc: () => { const s = SC.grenadier; return [
        `Wirft eine Granate genau ${s.min} Felder vorwärts (gerade oder schräg, ${vtxt(s.maxValue[0])}).`,
        `Entfernung ${s.min} bis ${s.max[1]}, ${vtxt(s.maxValue[1])}, gegnerische Bauern-Klasse neben dem Einschlag fliegt mit weg.`,
        `Wie Stufe 2, Entfernung ${s.min} bis ${s.max[2]}.`]; }
    })
  });

  // ---------- Neue Figuren: Springer-Klasse ----------
  def('zebra', {
    name: 'Zebra', abbr: 'Ze', cls: 'springer', rarity: 'gewoehnlich', value: 2, cost: 2,
    move: { leaps: ZEBRA },
    moveText: 'Springt 3 Felder in eine Richtung und 2 zur Seite. Springt über Figuren.',
    special: T.blink('zebra', {
      name: 'Steppenlauf',
      desc: () => { const s = SC.zebra; return [
        `Rennt auf ein beliebiges leeres Feld im Radius ${s.radius[0]} (ignoriert Blockaden, ohne zu schlagen).`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}.`]; }
    })
  });

  def('giraffe', {
    name: 'Giraffe', abbr: 'Gi', cls: 'springer', rarity: 'gewoehnlich', value: 1.8, cost: 2,
    move: { leaps: GIRAFFE },
    moveText: 'Springt 4 Felder in eine Richtung und 1 zur Seite. Springt über Figuren.',
    special: T.stun('giraffe', {
      name: 'Kopfnuss', dirs: 'all', jump: true, proj: 'star',
      desc: () => { const s = SC.giraffe; return [
        `Friert eine gegnerische Figur bis ${s.max[0]} Felder entfernt (gerade oder schräg, über alles hinweg) ${zug(s.dur[0])} ein.`,
        `Reichweite ${s.max[1]}.`,
        `Reichweite ${s.max[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  def('wolf', {
    name: 'Wolf', abbr: 'Wo', cls: 'springer', rarity: 'gewoehnlich', value: 3.2, cost: 3,
    move: { leaps: KING },
    moveText: 'Zieht 1 Feld in jede Richtung (wie ein König, kann aber geschlagen werden).',
    special: T.pounce('wolf', {
      name: 'Rudeljagd',
      desc: () => { const s = SC.wolf; return [
        `Springt auf ein Feld im Radius ${s.radius[0]} und darf dort schlagen (${vtxt(s.maxValue[0])}).`,
        `${vtxt(s.maxValue[1])}.`,
        `Figuren bis Wert ${s.maxValue[2]}.`]; }
    })
  });

  def('gaukler', {
    name: 'Gaukler', abbr: 'Ga', cls: 'springer', rarity: 'gewoehnlich', value: 1.8, cost: 2,
    move: { leaps: ALFIL.concat(DABBABA) },
    moveText: 'Springt genau 2 Felder gerade oder 2 Felder schräg. Springt über Figuren.',
    special: T.swapAlly('gaukler', {
      name: 'Platzwechsel',
      desc: () => { const s = SC.gaukler; return [
        `Tauscht den Platz mit einer eigenen Figur im Radius ${s.radius[0]} (nicht mit dem König).`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, die getauschte Figur bekommt 1 Zug Schild.`]; }
    })
  });

  def('fuchs', {
    name: 'Fuchs', abbr: 'Fu', cls: 'springer', rarity: 'selten', value: 2.2, cost: 2,
    move: { leaps: DIAG.concat(DABBABA) },
    moveText: 'Zieht 1 Feld schräg oder springt genau 2 Felder gerade.',
    special: T.swapEnemy('fuchs', {
      name: 'Täuschung',
      desc: () => { const s = SC.fuchs; return [
        `Tauscht den Platz mit einer angrenzenden gegnerischen Figur (${vtxt(s.maxValue[0])}).`,
        `${vtxt(s.maxValue[1])}.`,
        `${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('einhorn', {
    name: 'Einhorn', abbr: 'Eh', cls: 'springer', rarity: 'selten', value: 4.7, cost: 5,
    move: { leaps: KNIGHT.concat(CAMEL) },
    moveText: 'Springt wie ein Springer oder wie ein Kamel (3 und 1).',
    special: T.strike('einhorn', {
      name: 'Hornstoß', vecs: KNIGHT, proj: 'horn',
      desc: () => { const s = SC.einhorn; return [
        `Stößt mit dem Horn: schlägt eine Figur auf einem Springerfeld, ohne sich zu bewegen (${vtxt(s.maxValue[0])}).`,
        `Figuren bis Wert ${s.maxValue[1]}.`,
        `${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('ninja', {
    name: 'Ninja', abbr: 'Nj', cls: 'springer', rarity: 'episch', value: 4.2, cost: 5,
    move: { leaps: KNIGHT.concat(DIAG) },
    moveText: 'Springt wie ein Springer oder zieht 1 Feld schräg.',
    special: T.stun('ninja', {
      name: 'Shuriken', dirs: 'all', jump: true, proj: 'star',
      desc: () => { const s = SC.ninja; return [
        `Wirft einen Shuriken über alles hinweg: friert eine gegnerische Figur genau ${s.min} Felder entfernt ${zug(s.dur[0])} ein.`,
        `Entfernung ${s.min} bis ${s.max[1]}, ${zug(s.dur[1])}.`,
        `Entfernung ${s.min} bis ${s.max[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  def('nachtreiter', {
    name: 'Nachtreiter', abbr: 'Nr', cls: 'springer', rarity: 'episch', value: 5, cost: 5,
    move: { rides: { dirs: KNIGHT, max: 7 } },
    moveText: 'Springt beliebig viele Springersprünge in dieselbe Richtung, solange die Landefelder frei sind.',
    special: T.pounce('nachtreiter', {
      name: 'Schattenritt',
      desc: () => { const s = SC.nachtreiter; return [
        `Reitet durch die Schatten auf ein Feld im Radius ${s.radius[0]} und darf dort schlagen (${vtxt(s.maxValue[0])}).`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('drache', {
    name: 'Drache', abbr: 'Dr', cls: 'springer', rarity: 'legendaer', value: 9, cost: 10,
    move: { rides: { dirs: ORTH, max: 7 }, leaps: KNIGHT },
    moveText: 'Zieht wie ein Turm oder springt wie ein Springer.',
    special: T.shot('drache', {
      name: 'Feueratem', anim: 'beam', dirs: 'orth', jump: false, proj: 'fire', style: 'burn',
      desc: () => { const s = SC.drache; return [
        `Speit Feuer gerade: verbrennt die erste gegnerische Figur innerhalb von ${s.range[0]} Feldern (${vtxt(s.maxValue[0])}).`,
        `Reichweite ${s.range[1]}, ${vtxt(s.maxValue[1])}.`,
        `Reichweite ${s.range[2]}, ${vtxt(s.maxValue[2])}, das Feuer trifft bis zu ${s.hits[2]} Figuren.`]; }
    })
  });

  // ---------- Neue Figuren: Läufer-Klasse ----------
  def('elefant', {
    name: 'Elefant', abbr: 'El', cls: 'laeufer', rarity: 'gewoehnlich', value: 1.8, cost: 2,
    move: { leaps: DIAG.concat(ALFIL) },
    moveText: 'Zieht 1 Feld schräg oder springt genau 2 Felder schräg.',
    special: T.charge('elefant', {
      name: 'Stampede', dirs: 'diag',
      desc: () => { const s = SC.elefant; return [
        `Trampelt schräg bis zu ${s.range[0]} Felder und überrennt die erste gegnerische Figur (${vtxt(s.maxValue[0])}).`,
        `${vtxt(s.maxValue[1])}.`,
        `Reichweite ${s.range[2]}, Figuren bis Wert ${s.maxValue[2]}.`]; }
    })
  });

  def('hofnarr', {
    name: 'Hofnarr', abbr: 'Hn', cls: 'laeufer', rarity: 'gewoehnlich', value: 3, cost: 3,
    move: { rides: { dirs: DIAG, max: 2 }, leaps: DABBABA },
    moveText: 'Zieht bis zu 2 Felder schräg oder springt genau 2 Felder gerade.',
    special: T.pull('hofnarr', {
      name: 'Narrenkette',
      desc: () => { const s = SC.hofnarr; return [
        `Zieht eine gegnerische Figur in freier Linie (bis ${s.range[0]} Felder, ${vtxt(s.maxValue[0])}) ${s.steps[0]} Feld zu sich heran.`,
        `Reichweite ${s.range[1]}, zieht ${s.steps[1]} Felder heran.`,
        `Reichweite ${s.range[2]}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('schattenlaeufer', {
    name: 'Schattenläufer', abbr: 'Sh', cls: 'laeufer', rarity: 'selten', value: 3.25, cost: 4,
    move: { rides: { dirs: DIAG, max: 7 } },
    moveText: 'Zieht beliebig weit diagonal.',
    special: T.blink('schattenlaeufer', {
      name: 'Schattenschritt',
      desc: () => { const s = SC.schattenlaeufer; return [
        `Verschwindet und taucht auf einem leeren Feld im Radius ${s.radius[0]} wieder auf.`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}.`]; }
    })
  });

  def('alchemist', {
    name: 'Alchemist', abbr: 'Al', cls: 'laeufer', rarity: 'selten', value: 3.3, cost: 4,
    move: { rides: { dirs: DIAG, max: 3 }, leaps: DABBABA },
    moveText: 'Zieht bis zu 3 Felder schräg oder springt genau 2 Felder gerade.',
    special: T.demote('alchemist', {
      name: 'Bleitrank',
      desc: () => { const s = SC.alchemist; return [
        `Verwandelt eine gegnerische Figur im Radius ${s.radius[0]} in eine schwächere (Dame wird Turm, Turm wird Läufer, Läufer wird Springer, Springer wird Bauer, ${vtxt(s.maxValue[0])}).`,
        `Radius ${s.radius[1]}, ${vtxt(s.maxValue[1])}.`,
        `Radius ${s.radius[2]}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('kardinal', {
    name: 'Kardinal', abbr: 'Kd', cls: 'laeufer', rarity: 'episch', value: 4.8, cost: 5,
    move: { rides: { dirs: DIAG, max: 7 }, leaps: ORTH },
    moveText: 'Zieht wie ein Läufer oder 1 Feld gerade.',
    special: T.aura('kardinal', {
      name: 'Segen', cleanse: true,
      desc: () => { const s = SC.kardinal; return [
        `Befreit eigene Figuren im Radius ${s.radius[0]} vom Eis und gibt ihnen ${zug(s.dur[0])} Schild.`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])} Schild.`]; }
    })
  });

  def('druide', {
    name: 'Druide', abbr: 'Du', cls: 'laeufer', rarity: 'episch', value: 5.5, cost: 6,
    move: { rides: { dirs: DIAG, max: 3 }, leaps: KNIGHT },
    moveText: 'Zieht bis zu 3 Felder schräg oder springt wie ein Springer.',
    special: T.nova('druide', {
      name: 'Rankenfessel', anim: 'vines',
      desc: () => { const s = SC.druide; return [
        `Ranken fesseln alle gegnerischen Figuren im Radius ${s.radius[0]} für ${zug(s.dur[0])}.`,
        `${zug(s.dur[1])}.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  // ---------- Neue Figuren: Turm-Klasse ----------
  def('wachposten', {
    name: 'Wachposten', abbr: 'Wp', cls: 'turm', rarity: 'gewoehnlich', value: 2.8, cost: 3,
    move: { rides: { dirs: ORTH, max: 2 } },
    moveText: 'Zieht bis zu 2 Felder gerade. Kann rochieren.',
    special: T.stun('wachposten', {
      name: 'Haltruf', dirs: 'orth', jump: false, proj: 'ice',
      desc: () => { const s = SC.wachposten; return [
        `Die erste gegnerische Figur in gerader Linie (bis ${s.max[0]} Felder) erstarrt ${zug(s.dur[0])}.`,
        `Reichweite ${s.max[1]}.`,
        `Reichweite ${s.max[2]}, ${zug(s.dur[2])}.`]; }
    })
  });

  def('bergtroll', {
    name: 'Bergtroll', abbr: 'Bt', cls: 'turm', rarity: 'gewoehnlich', value: 2.8, cost: 3,
    move: { leaps: ORTH.concat(DABBABA) },
    moveText: 'Zieht 1 Feld gerade oder springt genau 2 Felder gerade. Kann rochieren.',
    special: T.push('bergtroll', {
      name: 'Keulenschwung', orth: true, anim: 'stomp',
      desc: () => { const s = SC.bergtroll; return [
        `Schleudert gerade angrenzende Gegner ${s.dist[0]} Feld weg.`,
        `Bis zu ${s.dist[1]} Felder weit.`,
        `${s.dist[2]} Felder, wer gegen eine Figur oder den Rand prallt, wird zerstört.`]; }
    })
  });

  def('yeti', {
    name: 'Yeti', abbr: 'Ye', cls: 'turm', rarity: 'selten', value: 3.6, cost: 4,
    move: { rides: { dirs: ORTH, max: 2 }, leaps: DIAG },
    moveText: 'Zieht bis zu 2 Felder gerade oder 1 Feld schräg. Kann rochieren.',
    special: T.nova('yeti', {
      name: 'Schneesturm',
      desc: () => { const s = SC.yeti; return [
        `Alle gegnerischen Figuren im Radius ${s.radius[0]} frieren ${zug(s.dur[0])} ein.`,
        'Wie Stufe 1, der Yeti bekommt dabei nichts ab.',
        `Radius ${s.radius[2]}.`]; }
    })
  });

  def('ballista', {
    name: 'Ballista', abbr: 'Ba', cls: 'turm', rarity: 'selten', value: 3.8, cost: 4,
    move: { rides: { dirs: ORTH, max: 3 } },
    moveText: 'Zieht bis zu 3 Felder gerade. Kann rochieren.',
    special: T.shot('ballista', {
      name: 'Bolzenschuss', dirs: 'orth', jump: true, proj: 'bolt', style: 'knock',
      desc: () => { const s = SC.ballista; return [
        `Schießt gerade über alles hinweg auf eine gegnerische Figur ${s.min} bis ${s.max[0]} Felder entfernt (${vtxt(s.maxValue[0])}).`,
        `Entfernung ${s.min} bis ${s.max[1]}, ${vtxt(s.maxValue[1])}.`,
        `Entfernung ${s.min} bis ${s.max[2]}.`]; }
    })
  });

  def('titan', {
    name: 'Titan', abbr: 'Ti', cls: 'turm', rarity: 'episch', value: 7, cost: 8,
    move: { rides: { dirs: ORTH, max: 7 }, leaps: DIAG },
    moveText: 'Zieht wie ein Turm oder 1 Feld schräg. Kann rochieren.',
    special: T.charge('titan', {
      name: 'Titanensturm', dirs: 'orth',
      desc: () => { const s = SC.titan; return [
        `Stürmt gerade bis zu ${s.range[0]} Felder und zermalmt die erste gegnerische Figur (${vtxt(s.maxValue[0])}).`,
        `Reichweite ${s.range[1]}, ${vtxt(s.maxValue[1])}.`,
        `Reichweite ${s.range[2]}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('kraken', {
    name: 'Kraken', abbr: 'Kr', cls: 'turm', rarity: 'legendaer', value: 7.5, cost: 8,
    move: { rides: { dirs: ORTH, max: 7 }, leaps: CAMEL },
    moveText: 'Zieht wie ein Turm oder springt wie ein Kamel (3 und 1).',
    special: T.lineFreeze('kraken', {
      name: 'Tintenflut',
      desc: () => { const s = SC.kraken; return [
        `Tinte flutet alle geraden Linien bis ${s.range[0]} Felder: jede gegnerische Figur darin ist ${zug(s.dur[0])} eingefroren (durchdringt Figuren).`,
        `Reichweite ${s.range[1]}.`,
        `Reichweite ${s.range[2]}.`]; }
    })
  });

  // ---------- Neue Figuren: Dame-Klasse ----------
  def('herzogin', {
    name: 'Herzogin', abbr: 'Hz', cls: 'dame', rarity: 'selten', value: 4.5, cost: 5,
    move: { rides: { dirs: ALL, max: 2 } },
    moveText: 'Zieht wie eine Dame, aber höchstens 2 Felder weit.',
    special: T.aura('herzogin', {
      name: 'Hofschild',
      desc: () => { const s = SC.herzogin; return [
        `Eigene Figuren im Radius ${s.radius[0]} erhalten ${zug(s.dur[0])} Schild.`,
        `${zug(s.dur[1])} Schild.`,
        `Radius ${s.radius[2]}, ${zug(s.dur[2])} Schild.`]; }
    })
  });

  def('walkuere', {
    name: 'Walküre', abbr: 'Wk', cls: 'dame', rarity: 'episch', value: 8, cost: 9,
    move: { rides: { dirs: ALL, max: 5 } },
    moveText: 'Zieht wie eine Dame, aber höchstens 5 Felder weit.',
    special: T.aura('walkuere', {
      name: 'Schlachtruf', cleanse: true,
      desc: () => { const s = SC.walkuere; return [
        `Eigene Figuren im Radius ${s.radius[0]} werden vom Eis befreit und erhalten ${zug(s.dur[0])} Schild.`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}, die Walküre selbst bekommt ebenfalls Schild.`]; }
    })
  });

  def('sphinx', {
    name: 'Sphinx', abbr: 'Sx', cls: 'dame', rarity: 'legendaer', value: 11, cost: 12,
    move: { rides: { dirs: ALL, max: 7 }, leaps: CAMEL },
    moveText: 'Zieht wie eine Dame oder springt wie ein Kamel (3 und 1).',
    special: T.stun('sphinx', {
      name: 'Rätselbann', dirs: 'all', jump: false, proj: 'star',
      desc: () => { const s = SC.sphinx; return [
        `Die erste gegnerische Figur in Damenlinie (bis ${s.range[0]} Felder, ${vtxt(s.maxValue[0])}) erstarrt ${zug(s.dur[0])}.`,
        `Reichweite ${s.range[1]}, ${zug(s.dur[1])}.`,
        `Reichweite ${inf(s.range[2])}, ${vtxt(s.maxValue[2])}.`]; }
    })
  });

  def('phoenix', {
    name: 'Phönix', abbr: 'Ph', cls: 'dame', rarity: 'legendaer', value: 8.8, cost: 10,
    move: { rides: { dirs: ALL, max: 3 }, leaps: KNIGHT },
    moveText: 'Zieht wie eine Dame bis 3 Felder weit oder springt wie ein Springer.',
    special: T.sweep('phoenix', {
      name: 'Feuerschwinge',
      desc: () => { const s = SC.phoenix; return [
        'Verbrennt alle angrenzenden gegnerischen Figuren der Bauern-Klasse.',
        'Zusätzlich frieren alle anderen angrenzenden Gegner 1 Zug ein.',
        `Einfrieren im Radius ${s.radius[2]}.`]; }
    })
  });

  // ---------- Neue Figuren: König-Klasse ----------
  def('feldherr', {
    name: 'Feldherr', abbr: 'Fh', cls: 'koenig', rarity: 'selten', value: 0, cost: 2, royal: true,
    move: { leaps: KING.concat(ALFIL) },
    moveText: 'Wie ein König, darf zusätzlich genau 2 Felder schräg springen.',
    special: T.spawn('feldherr', {
      name: 'Leibgarde',
      desc: () => { const s = SC.feldherr; return [
        'Ruft einen Bauern auf ein freies Feld gerade neben den Feldherrn.',
        `Ruft ${s.count[1]} Bauern.`,
        `Ruft ${s.count[2]} Bauern mit je 1 Zug Schild.`]; }
    })
  });

  def('sultan', {
    name: 'Sultan', abbr: 'Su', cls: 'koenig', rarity: 'episch', value: 0, cost: 3, royal: true,
    move: { leaps: KING },
    moveText: 'Zieht 1 Feld in jede Richtung wie ein König.',
    special: T.blink('sultan', {
      name: 'Fliegender Teppich', noInCheck: true,
      desc: () => { const s = SC.sultan; return [
        `Fliegt auf ein leeres Feld im Radius ${s.radius[0]}, das nicht angegriffen wird. Nicht möglich, wenn der Sultan im Schach steht.`,
        `Radius ${s.radius[1]}.`,
        `Radius ${s.radius[2]}.`]; }
    })
  });

  def('pharao', {
    name: 'Pharao', abbr: 'Pr', cls: 'koenig', rarity: 'legendaer', value: 0, cost: 4, royal: true,
    move: { leaps: KING },
    moveText: 'Zieht 1 Feld in jede Richtung wie ein König.',
    special: T.nova('pharao', {
      name: 'Fluch des Pharao', anim: 'curse',
      desc: () => { const s = SC.pharao; return [
        `Alle gegnerischen Figuren im Radius ${s.radius[0]} erstarren ${zug(s.dur[0])}.`,
        'Wie Stufe 1.',
        `Radius ${s.radius[2]}.`]; }
    })
  });

  // ---------- Vorberechnung ----------
  const ORDER = ['bauer', 'springer', 'laeufer', 'turm', 'dame', 'koenig',
    'spaeher', 'lanzentraeger', 'kamelreiter', 'greif', 'moench', 'erzmagier',
    'golem', 'katapult', 'hexe', 'amazone', 'waechter', 'kaiser',
    'schleicher', 'fahnentraeger', 'bogenschuetze', 'grenadier',
    'zebra', 'giraffe', 'wolf', 'gaukler', 'fuchs', 'einhorn', 'ninja', 'nachtreiter', 'drache',
    'elefant', 'hofnarr', 'schattenlaeufer', 'alchemist', 'kardinal', 'druide',
    'wachposten', 'bergtroll', 'yeti', 'ballista', 'titan', 'kraken',
    'herzogin', 'walkuere', 'sphinx', 'phoenix',
    'feldherr', 'sultan', 'pharao'];
  ORDER.forEach((k, i) => {
    const d = P[k];
    if (!d) throw new Error('Figur fehlt: ' + k);
    d.index = i;
    d.royal = !!d.royal;
    const set = new Set();
    (d.move.leaps || []).forEach(v => set.add((v[1] + 8) * 17 + (v[0] + 8)));
    d.move.leapSet = set;
    if (d.move.rides) {
      const unit = d.move.rides.dirs.every(v => Math.abs(v[0]) <= 1 && Math.abs(v[1]) <= 1);
      d.move.rides.unit = unit;
      d.move.rideSet = new Set(d.move.rides.dirs.map(v => (v[1] + 1) * 3 + (v[0] + 1)));
    }
  });

  GJ.PIECES = P;
  GJ.PIECE_ORDER = ORDER;
  GJ.STANDARD_TYPES = ORDER.slice(0, 6);
  GJ.NEW_TYPES = ORDER.slice(6);
  GJ.CLASS_NAMES = { bauer: 'Bauer', springer: 'Springer', laeufer: 'Läufer', turm: 'Turm', dame: 'Dame', koenig: 'König' };
  GJ.svgFor = K.svgFor;
  GJ.lv = lv;
  GJ.SPECIAL_TEMPLATES = T;
})();
