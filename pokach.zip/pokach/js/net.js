/* =====================================================================
   POKACH - net.js
   Online-Multiplayer über WebRTC (PeerJS).
   Erkennung im selben WLAN: Alle Geräte in einem WLAN haben dieselbe
   öffentliche IP. Daraus wird ein kurzer Hash gebildet, und jedes Gerät
   belegt eine von wenigen festen Adressen "pokach-v1-<hash>-<n>".
   Die anderen Adressen werden regelmäßig abgefragt, so finden sich die
   Geräte ohne eigenen Server. Zusätzlich gibt es einen Spielcode zum
   Eintippen, falls die Erkennung nicht klappt (z. B. Schul-WLAN).
   Test ohne Internet: index.html?nettest=1 (zwei Tabs im selben Browser).
   ===================================================================== */
var GJ = globalThis.GJ = globalThis.GJ || {};
(function () {
  const C = GJ.CONFIG, OC = C.online;
  const N = GJ.Net = { status: 'aus', peers: new Map(), conns: new Map(), opp: null, myId: null, code: null, err: null };
  const ic = (n, c) => GJ.icon(n, c);
  const VERSION = 1;

  // ---------------- Hilfen ----------------
  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(36).slice(0, 6);
  }
  function loadScript(url) {
    return new Promise((res, rej) => {
      if (window.Peer) { res(); return; }
      const s = document.createElement('script');
      s.src = url; s.async = true;
      s.onload = () => res(); s.onerror = () => rej(new Error('PeerJS konnte nicht geladen werden'));
      document.head.appendChild(s);
    });
  }
  async function publicIP() {
    for (const url of OC.ipEndpoints) {
      try {
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4000);
        const r = await fetch(url, { cache: 'no-store', signal: ctl.signal });
        clearTimeout(t);
        if (!r.ok) continue;
        const j = await r.json();
        if (j && j.ip) return String(j.ip);
      } catch (e) { /* nächsten probieren */ }
    }
    return null;
  }
  const testMode = () => /[?&]nettest=1/.test(location.search);
  N.name = () => (GJ.Save.d.playerName || '').trim() || 'Spieler';

  // ---------------- Transport: PeerJS ----------------
  function PeerTransport() { this.peer = null; }
  PeerTransport.prototype.start = async function (onConn) {
    await loadScript(OC.peerjsUrl);
    const ip = await publicIP();
    N.netHash = ip ? hash(ip + 'pokach') : null;
    const tryOpen = id => new Promise(res => {
      const p = new window.Peer(id, { debug: 0 });
      let done = false;
      p.on('open', i => { if (!done) { done = true; res({ p, id: i }); } });
      p.on('error', e => { if (!done) { done = true; try { p.destroy(); } catch (x) { /* egal */ } res({ err: e }); } });
      setTimeout(() => { if (!done) { done = true; try { p.destroy(); } catch (x) { /* egal */ } res({ err: { type: 'timeout' } }); } }, 9000);
    });
    let got = null;
    if (N.netHash) {
      for (let i = 0; i < OC.lobbySlots && !got; i++) {
        const r = await tryOpen(OC.prefix + N.netHash + '-' + i);
        if (r.p) got = r;
        else if (r.err && r.err.type !== 'unavailable-id') break;
      }
    }
    if (!got) {
      const r = await tryOpen(OC.prefix + 'x' + Math.random().toString(36).slice(2, 8));
      if (!r.p) throw new Error('Keine Verbindung zum Vermittlungsserver (' + (r.err && r.err.type) + ')');
      got = r;
    }
    this.peer = got.p;
    this.peer.on('connection', c => onConn(wrapPeerConn(c)));
    this.peer.on('error', e => { if (e && e.type === 'peer-unavailable') return; console.warn('[PK] Netz', e); });
    this.peer.on('disconnected', () => { try { this.peer.reconnect(); } catch (e) { /* egal */ } });
    return got.id;
  };
  PeerTransport.prototype.candidates = function () {
    if (!N.netHash) return [];
    const out = [];
    for (let i = 0; i < OC.lobbySlots; i++) out.push(OC.prefix + N.netHash + '-' + i);
    return out;
  };
  PeerTransport.prototype.connect = function (id) { return wrapPeerConn(this.peer.connect(id, { reliable: true })); };
  PeerTransport.prototype.stop = function () { try { this.peer && this.peer.destroy(); } catch (e) { /* egal */ } this.peer = null; };
  function wrapPeerConn(c) {
    return { id: c.peer, raw: c, on: (ev, fn) => c.on(ev, fn), send: d => { try { c.send(d); } catch (e) { /* egal */ } }, close: () => { try { c.close(); } catch (e) { /* egal */ } } };
  }

  // ---------------- Transport: BroadcastChannel (nur zum Testen) ----------------
  function BCTransport() { this.bc = null; this.handlers = new Map(); this.seen = new Set(); }
  BCTransport.prototype.start = async function (onConn) {
    this.bc = new BroadcastChannel('pokach-nettest');
    this.id = OC.prefix + 't' + Math.random().toString(36).slice(2, 7);
    this.onConn = onConn;
    this.bc.onmessage = e => {
      const m = e.data;
      if (m.type === 'ann' && m.from !== this.id) this.seen.add(m.from);
      if (m.to !== this.id) return;
      if (m.type === 'open') { const c = this.mk(m.from); this.onConn(c); setTimeout(() => { this.bc.postMessage({ type: 'opened', from: this.id, to: m.from }); c._emit('open'); }, 10); }
      else if (m.type === 'opened') { const c = this.handlers.get(m.from); if (c) c._emit('open'); }
      else if (m.type === 'data') { const c = this.handlers.get(m.from); if (c) c._emit('data', m.data); }
      else if (m.type === 'close') { const c = this.handlers.get(m.from); if (c) { c._emit('close'); this.handlers.delete(m.from); } }
    };
    this.annTimer = setInterval(() => this.bc && this.bc.postMessage({ type: 'ann', from: this.id }), 700);
    this.bc.postMessage({ type: 'ann', from: this.id });
    return this.id;
  };
  BCTransport.prototype.mk = function (other) {
    const ev = {};
    const c = { id: other, on: (n, f) => { (ev[n] = ev[n] || []).push(f); }, _emit: (n, d) => (ev[n] || []).forEach(f => f(d)),
      send: d => this.bc && this.bc.postMessage({ type: 'data', from: this.id, to: other, data: d }),
      close: () => { this.bc && this.bc.postMessage({ type: 'close', from: this.id, to: other }); this.handlers.delete(other); } };
    this.handlers.set(other, c);
    return c;
  };
  BCTransport.prototype.candidates = function () { return [...this.seen]; };
  BCTransport.prototype.connect = function (id) { const c = this.mk(id); this.bc.postMessage({ type: 'open', from: this.id, to: id }); return c; };
  BCTransport.prototype.stop = function () { clearInterval(this.annTimer); try { this.bc.close(); } catch (e) { /* egal */ } this.bc = null; };

  // ---------------- Verbindungen ----------------
  function attach(c) {
    if (N.conns.has(c.id) && N.conns.get(c.id) !== c) return;
    N.conns.set(c.id, c);
    c.on('open', () => c.send({ t: 'hello', name: N.name(), v: VERSION, busy: !!N.opp }));
    c.on('data', d => onData(c, d));
    c.on('close', () => onClose(c));
    c.on('error', () => onClose(c));
  }
  function onClose(c) {
    N.conns.delete(c.id);
    N.peers.delete(c.id);
    if (N.opp === c.id) { N.opp = null; if (GJ.Match && GJ.Match.mode === 'online') GJ.Match.netLost(); }
    N.render();
  }
  N.code = id => (id || '').replace(OC.prefix, '');

  N.start = async function () {
    if (N.status === 'bereit' || N.status === 'startet') return;
    N.status = 'startet'; N.err = null; N.render();
    try {
      N.tr = testMode() ? new BCTransport() : new PeerTransport();
      N.myId = await N.tr.start(c => attach(c));
      N.status = 'bereit';
      N.scan();
      setTimeout(N.scan, 1200);
      N.scanTimer = setInterval(N.scan, 3000);
    } catch (e) {
      N.status = 'fehler'; N.err = e.message || String(e);
    }
    N.render();
  };
  N.stop = function () {
    clearInterval(N.scanTimer);
    for (const c of N.conns.values()) c.close();
    N.conns.clear(); N.peers.clear(); N.opp = null;
    if (N.tr) N.tr.stop();
    N.tr = null; N.status = 'aus';
  };
  N.scan = function () {
    if (!N.tr || N.status !== 'bereit') return;
    for (const id of N.tr.candidates()) {
      if (id === N.myId || N.conns.has(id) || id < N.myId) continue;   // nur einer der beiden baut auf
      try { attach(N.tr.connect(id)); } catch (e) { /* nicht erreichbar */ }
    }
  };
  N.connectCode = function (code) {
    code = String(code || '').trim().toLowerCase().replace(/\s+/g, '');
    if (!code) return;
    const id = OC.prefix + code;
    if (id === N.myId) { GJ.UI.toast('Das ist dein eigener Code'); return; }
    if (!N.tr) { GJ.UI.toast('Noch nicht verbunden'); return; }
    attach(N.tr.connect(id));
    GJ.UI.toast('Verbinde mit ' + code + ' ...');
  };
  N.send = function (msg) { const c = N.opp && N.conns.get(N.opp); if (c) c.send(msg); };
  N.leaveGame = function () { const c = N.opp && N.conns.get(N.opp); if (c) c.send({ t: 'left' }); N.opp = null; N.broadcastBusy(); };
  N.broadcastBusy = function () { for (const c of N.conns.values()) c.send({ t: 'status', busy: !!N.opp }); };

  // ---------------- Spielvorbereitung ----------------
  function myOffer() {
    const S = GJ.Save, dk = S.activeDeck();
    return { name: N.name(), deck: Object.assign({}, dk.layout), levels: S.playerLevels(), promo: S.promoOptions() };
  }
  function sanitize(o) {
    const deck = {};
    for (const k in (o.deck || {})) if (/^[a-h][12]$/.test(k) && GJ.PIECES[o.deck[k]]) deck[k] = o.deck[k];
    const levels = {};
    for (const t in (o.levels || {})) if (GJ.PIECES[t]) levels[t] = Math.max(0, Math.min(3, o.levels[t] | 0));
    const promo = (o.promo || []).filter(t => GJ.PIECES[t] && ['dame', 'turm', 'laeufer', 'springer'].includes(GJ.PIECES[t].cls) && GJ.PIECES[t].value <= 9);
    const v = GJ.Deck.validate(deck, false, { budget: OC.budget });
    return { name: String(o.name || 'Gegner').slice(0, 14), deck, levels, promo: promo.length ? promo : ['dame', 'turm', 'laeufer', 'springer'], valid: v.valid };
  }
  N.challenge = function (id) {
    const v = GJ.Deck.validate(GJ.Save.activeDeck().layout, true, { budget: OC.budget });
    if (!v.valid) { GJ.UI.toast('Dein aktives Deck ist ungültig: ' + v.errors[0]); return; }
    const c = N.conns.get(id);
    if (!c) return;
    N.pending = id;
    c.send(Object.assign({ t: 'invite' }, myOffer()));
    N.waitModal = GJ.UI.modal({ title: 'Herausforderung', html: `<p style="text-align:center">Warte auf ${esc((N.peers.get(id) || {}).name || 'Gegner')} ...</p>`, persistent: true,
      buttons: [{ label: 'Abbrechen', onClick: () => { c.send({ t: 'cancel' }); N.pending = null; } }] });
  };
  function esc(s) { return String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[ch]); }

  function onData(c, d) {
    if (!d || typeof d !== 'object') return;
    if (d.t === 'hello') { N.peers.set(c.id, { name: String(d.name || 'Spieler').slice(0, 14), busy: !!d.busy, v: d.v }); N.render(); return; }
    if (d.t === 'status') { const p = N.peers.get(c.id); if (p) { p.busy = !!d.busy; N.render(); } return; }
    if (d.t === 'invite') {
      if (N.opp || (GJ.Match && GJ.Match.mode === 'online' && !GJ.Match.over)) { c.send({ t: 'decline', why: 'beschäftigt' }); return; }
      const off = sanitize(d);
      if (!off.valid) { c.send({ t: 'decline', why: 'ungültiges Deck' }); return; }
      N.invite = { from: c.id, offer: off };
      GJ.Audio.play('jingle');
      N.inviteModal = GJ.UI.modal({ title: 'Herausforderung!', persistent: true,
        html: `<p style="text-align:center"><b>${esc(off.name)}</b> fordert dich heraus.</p>${GJ.UI.miniDeckHTML(off.deck, 'b')}`,
        buttons: [{ label: 'Ablehnen', cls: 'btn-berry', onClick: () => { c.send({ t: 'decline', why: 'abgelehnt' }); N.invite = null; } },
          { label: 'Annehmen', cls: 'btn-leaf', onClick: () => {
            const v = GJ.Deck.validate(GJ.Save.activeDeck().layout, true, { budget: OC.budget });
            if (!v.valid) { GJ.UI.toast('Dein aktives Deck ist ungültig: ' + v.errors[0]); c.send({ t: 'decline', why: 'Deck ungültig' }); return; }
            c.send(Object.assign({ t: 'accept' }, myOffer()));
          } }] });
      return;
    }
    if (d.t === 'cancel') { if (N.inviteModal) GJ.UI.closeModal(N.inviteModal); N.invite = null; GJ.UI.toast('Herausforderung zurückgezogen'); return; }
    if (d.t === 'decline') { if (N.waitModal) GJ.UI.closeModal(N.waitModal); N.pending = null; GJ.UI.toast('Abgelehnt (' + (d.why || '') + ')'); return; }
    if (d.t === 'accept' && N.pending === c.id) {
      if (N.waitModal) GJ.UI.closeModal(N.waitModal);
      const them = sanitize(d), me = sanitize(myOffer());
      if (!them.valid) { c.send({ t: 'decline', why: 'ungültiges Deck' }); return; }
      const myColor = Math.random() < 0.5 ? 'w' : 'b', oc = myColor === 'w' ? 'b' : 'w';
      const side = { [myColor]: me, [oc]: them };
      const setup = {
        white: side.w.deck, black: side.b.deck,
        levels: { w: side.w.levels, b: side.b.levels },
        promo: { w: side.w.promo, b: side.b.promo },
        names: { w: side.w.name, b: side.b.name },
        first: Math.random() < 0.5 ? 'w' : 'b'
      };
      N.opp = c.id; N.pending = null; N.broadcastBusy();
      c.send({ t: 'start', setup, color: oc });
      GJ.UI.go('game', { online: { setup, color: myColor } });
      return;
    }
    if (d.t === 'start' && N.invite && N.invite.from === c.id) {
      N.invite = null; N.opp = c.id; N.broadcastBusy();
      if (N.inviteModal) GJ.UI.closeModal(N.inviteModal);
      GJ.UI.go('game', { online: { setup: d.setup, color: d.color === 'b' ? 'b' : 'w' } });
      return;
    }
    if (c.id !== N.opp) return;
    if (d.t === 'move' && GJ.Match) GJ.Match.netMove(d);
    else if (d.t === 'resign' && GJ.Match) GJ.Match.netResign();
    else if (d.t === 'left') { N.opp = null; if (GJ.Match) GJ.Match.netLost(); }
  }

  // ---------------- Bildschirm ----------------
  N.render = function () { if (GJ.UI.current === 'online') GJ.UI.screens.online({ keep: true }); };
  GJ.UI = GJ.UI || {}; GJ.UI.screens = GJ.UI.screens || {};
  GJ.UI.screens.online = function (o) {
    const UI = GJ.UI, S = GJ.Save;
    if (!(o && o.keep)) N.start();
    const dk = S.activeDeck(), v = GJ.Deck.validate(dk.layout, true, { budget: OC.budget });
    const list = [...N.peers.entries()];
    const stTxt = { aus: 'Offline', startet: 'Verbinde ...', bereit: N.netHash || testMode() ? 'Suche Spieler im selben WLAN ...' : 'Bereit (WLAN-Suche nicht möglich, nutze den Code)', fehler: 'Fehler: ' + (N.err || '') }[N.status];
    const app = UI.shell('home', 'Online', `
      <div class="panel online-box">
        <div class="set-row"><div>Dein Name</div><input type="text" id="pname" maxlength="14" value="${esc(S.d.playerName || '')}" placeholder="Spieler"></div>
        <div class="set-row"><div>Status<div class="desc">${esc(stTxt)}</div></div>${N.status === 'fehler' ? `<button class="btn btn-sm btn-blue" id="retry">Nochmal</button>` : ic(N.status === 'bereit' ? 'wifi' : 'info')}</div>
        <div class="set-row"><div>Dein Code<div class="desc">Für Freunde in anderen Netzen</div></div><div class="code-chip">${N.myId ? esc(N.code(N.myId)) : '...'}</div></div>
        <div class="set-row"><input type="text" id="ocode" placeholder="Code des Freundes" autocapitalize="off"><button class="btn btn-sm btn-blue" id="ocon">Verbinden</button></div>
      </div>
      <div class="deck-chip" id="odeck">${ic('deck')}<span class="dn">Deck: ${esc(dk.name)}</span>${v.valid ? '' : `<span style="color:var(--berry-dk)">ungültig</span>`}${ic('next')}</div>
      <div class="label" style="color:#fff">Gefundene Spieler</div>
      <div class="online-list">${list.length ? list.map(([id, p]) => `<div class="panel op-row"><div class="team-dot">${GJ.PIECES.koenig.svg('b', false)}</div><div class="op-nm">${esc(p.name)}<div class="desc">${p.busy ? 'spielt gerade' : 'bereit'}</div></div><button class="btn btn-sm btn-sun" data-ch="${esc(id)}" ${p.busy ? 'disabled' : ''}>Herausfordern</button></div>`).join('') : `<div class="panel" style="padding:14px;text-align:center;font-weight:400">Noch niemand gefunden. Öffne Pokach auf einem zweiten Gerät im selben WLAN und tippe dort auf Online.</div>`}</div>
      <p style="color:#e6eeff;font-size:12px;font-weight:400;text-align:center">Online spielt jeder mit seinem aktiven Deck (Budget ${OC.budget}) und seinen eigenen Stufen. Online-Partien geben keine EP.</p>`, { back: true, onBack: () => { N.stop(); UI.go('home'); } });
    const pn = app.querySelector('#pname');
    pn.onchange = () => { S.d.playerName = pn.value.trim().slice(0, 14); S.save(); for (const c of N.conns.values()) c.send({ t: 'hello', name: N.name(), v: VERSION, busy: !!N.opp }); };
    const rt = app.querySelector('#retry'); if (rt) UI.tap(rt, () => { N.stop(); N.start(); });
    UI.tap(app.querySelector('#ocon'), () => N.connectCode(app.querySelector('#ocode').value));
    UI.tap(app.querySelector('#odeck'), () => UI.pickDeck());
    app.querySelectorAll('[data-ch]').forEach(b => UI.tap(b, () => N.challenge(b.dataset.ch)));
  };
})();
