/* =====================================================================
   POKACH - pieces.js
   Alle 50 Figuren: Bewegung, Werte, Seltenheit, Specials, SVG.
   Neue Figur = neuer Eintrag hier. Specials werden aus Bausteinen
   (Schuss, Frost, Schild, Teleport ...) zusammengesetzt, die Zahlen
   stehen in GJ.CONFIG.specials.
   ===================================================================== */
var GJ = globalThis.GJ = globalThis.GJ || {};
(function () {
  const SC = GJ.CONFIG.specials;
  const sym = (a, b) => {
    const s = new Set(), o = [];
    for (const [x, y] of [[a, b], [b, a]]) for (const sx of [1, -1]) for (const sy of [1, -1]) {
      const k = (x * sx) + ',' + (y * sy);
      if (!s.has(k)) { s.add(k); o.push([x * sx, y * sy]); }
    }
    return o;
  };
  const KNIGHT = sym(1, 2), CAMEL = sym(1, 3), ZEBRA = sym(2, 3), GIRAFFE = sym(1, 4);
  const ORTH = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const DIAG = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
  const KING = ORTH.concat(DIAG);
  const ALL = KING;
  const ALFIL = sym(2, 2), DABBABA = sym(0, 2);
  GJ.DIRS = { KNIGHT, KING, CAMEL, ORTH, DIAG, ALL, ZEBRA, GIRAFFE, ALFIL, DABBABA };

  const lv = (arr, l) => Array.isArray(arr) ? arr[Math.max(0, Math.min(arr.length - 1, l - 1))] : arr;
  const inf = n => (n >= 7 ? 'unbegrenzt' : n);
  const vtxt = v => (v >= 9 ? 'jede Figur' : v >= 5 ? 'Figuren bis Wert ' + v + ' (keine Dame)' : v >= 3 ? 'Figuren bis Wert ' + v : 'nur Bauern-Klasse');
  const zug = n => n + (n === 1 ? ' Zug' : ' Züge');

  // ---------- Helfer ----------
  function E() { return GJ.E; }
  function V(t) { return GJ.PIECES[t].value; }
  function sm(st, sq, p, extra) {
    return Object.assign({ kind: 'special', stype: p.type, from: sq, to: sq, picks: [sq], caps: [], affects: [] }, extra);
  }
  function eachInRadius(sq, r, fn) {
    const f0 = sq & 7, r0 = sq >> 3;
    for (let dr = -r; dr <= r; dr++) for (let df = -r; df <= r; df++) {
      if (!df && !dr) continue;
      const f = f0 + df, rr = r0 + dr;
      if (f < 0 || f > 7 || rr < 0 || rr > 7) continue;
      fn(rr * 8 + f);
    }
  }
  function step(sq, d, k) {
    const f = (sq & 7) + d[0] * k, r = (sq >> 3) + d[1] * k;
    if (f < 0 || f > 7 || r < 0 || r > 7) return -1;
    return r * 8 + f;
  }
  GJ.stepSq = step;
  GJ.eachInRadius = eachInRadius;
  // gegnerische Figur, die getroffen werden darf (kein König, kein Schild, Wert-Grenze)
  function tOk(t, c, maxV) { return !!t && E().targetable(t, c) && (maxV == null || V(t.type) <= maxV + 1e-9); }
  function sumV(st, list) { let v = 0; for (const s of list) { const t = st.board[s]; if (t) v += V(t.type); } return v; }
  function radiusReach(R) { const o = []; for (let x = -R; x <= R; x++) for (let y = -R; y <= R; y++) if (x || y) o.push([x, y]); return o; }
  function lineReach(dirs, a, b) { const o = []; for (const d of dirs) for (let k = a; k <= Math.min(3, b); k++) o.push([d[0] * k, d[1] * k]); return o; }
  const fwd = c => (c === 'w' ? 1 : -1);
  const DIRSETS = {
    orth: () => ORTH, diag: () => DIAG, all: () => ALL, knight: () => KNIGHT,
    fwd: c => [[0, fwd(c)]], fwd3: c => [[0, fwd(c)], [-1, fwd(c)], [1, fwd(c)]], fwdDiag: c => [[-1, fwd(c)], [1, fwd(c)]]
  };

  // =====================================================================
  //  SVG-Kunst (viewBox 0..100, Sockel ab y=75 kommt automatisch)
  // =====================================================================
  const INK = '#14203d';
  const COLLAR = (y, w, x) => `<rect x="${(x || 50) - w / 2}" y="${y}" width="${w}" height="6" rx="3"/>`;
  const PAWNBODY = (x) => { x = x || 50; return `${COLLAR(42, 26, x)}<path d="M${x - 9} 48 Q${x - 10} 64 ${x - 19} 77 H${x + 19} Q${x + 10} 64 ${x + 9} 48 Z"/>`; };
  const BASEBODY = `<path d="M37 59 H63 L69 77 H31 Z"/>`;
  function gem(r) {
    if (r === 'standard') return '';
    const col = GJ.CONFIG.rarity[r].color;
    return `<path d="M50 76.5 l6 6 -6 6 -6 -6z" fill="${col}" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/>`;
  }
  const dc = () => INK;
  const GOLD = '#ffd36b';

  const ART = {
    bauer: () => `<circle cx="50" cy="27" r="12"/>${PAWNBODY()}`,
    springer: () => `<path d="M33 77 C33 62 38 55 45 49 C39 50 31 54 26 50 C22 46 26 40 32 36 C39 30 42 22 50 18 L52 9 L58 17 C71 21 77 36 75 52 C74 62 70 70 70 77 Z"/>
      <circle cx="47" cy="29" r="2.6" fill="${dc()}" stroke="none"/><path d="M58 22 C66 30 68 44 64 58" fill="none" stroke-width="2"/>`,
    laeufer: () => `<circle cx="50" cy="13" r="5"/><path d="M50 19 C37 29 33 42 39 52 H61 C67 42 63 29 50 19 Z"/>
      <path d="M55 29 L46 41" fill="none" stroke-width="3.5"/>${COLLAR(51, 26)}<path d="M42 57 Q41 68 33 77 H67 Q59 68 58 57 Z"/>`,
    turm: () => `<path d="M29 14 h9 v7 h7 v-7 h10 v7 h7 v-7 h9 v15 l-6 6 v28 l7 9 H28 l7-9 V35 l-6-6 Z"/>
      <path d="M38 40 H62 M38 54 H62" fill="none" stroke-width="2"/>`,
    dame: () => `<circle cx="25" cy="27" r="4"/><circle cx="41" cy="22" r="4"/><circle cx="59" cy="22" r="4"/><circle cx="75" cy="27" r="4"/><circle cx="50" cy="16" r="4.5"/>
      <path d="M25 31 L34 54 L41 26 L50 51 L59 26 L66 54 L75 31 L68 63 H32 Z"/><path d="M33 63 H67 L71 77 H29 Z"/>`,
    koenig: () => `<path d="M46.5 5 h7 v6 h6 v7 h-6 v8 h-7 v-8 h-6 v-7 h6 Z"/>
      <path d="M50 27 C37 27 29 36 33 48 L39 59 H61 L67 48 C71 36 63 27 50 27 Z"/><path d="M37 59 H63 L69 77 H31 Z"/>`,
    spaeher: () => `<path d="M58 32 L80 23 L83 30 L61 38 Z"/><path d="M78 22 L80 31" fill="none" stroke-width="2"/>
      <path d="M35 34 C35 16 65 16 65 34 C65 41 58 47 50 47 C42 47 35 41 35 34 Z"/>
      <ellipse cx="50" cy="35" rx="8" ry="7" fill="${dc()}" stroke="none" opacity="0.85"/>
      ${COLLAR(46, 28)}<path d="M41 52 Q40 66 31 77 H69 Q60 66 59 52 Z"/>`,
    lanzentraeger: () => `<path d="M71 86 L82 12" fill="none" stroke-width="5"/><path d="M82 3 L87 16 L77 14 Z"/>
      <path d="M81 15 L95 19 L80 25 Z" fill="${GJ.CONFIG.rarity.selten.color}"/>
      <circle cx="44" cy="27" r="12"/>${PAWNBODY(44)}`,
    kamelreiter: () => `<path d="M52 56 C54 44 66 40 74 48 C78 54 76 62 70 64 Z"/>
      <path d="M30 77 C30 63 36 53 43 47 C47 41 46 31 41 25 C38 19 42 12 51 12 C60 12 70 16 75 22 C77 27 72 29 66 27 C60 27 57 31 59 37 C61 45 69 52 70 77 Z"/>
      <circle cx="54" cy="18" r="2.4" fill="${dc()}" stroke="none"/><path d="M62 26 C58 34 50 38 44 36" fill="none" stroke-width="2"/>`,
    greif: () => `<path d="M48 52 C34 42 20 42 9 28 C14 48 24 58 40 62 Z"/><path d="M52 52 C66 42 80 42 91 28 C86 48 76 58 60 62 Z"/>
      <path d="M50 17 C60 17 66 25 64 35 L74 39 L63 42 C61 50 56 56 50 60 C44 56 39 48 39 37 C39 25 43 17 50 17 Z"/>
      <circle cx="54" cy="29" r="2.4" fill="${dc()}" stroke="none"/><path d="M38 61 H62 L67 77 H33 Z"/>`,
    moench: () => `<path d="M50 13 C37 13 31 26 31 40 C31 54 27 66 25 77 H75 C73 66 69 54 69 40 C69 26 63 13 50 13 Z"/>
      <path d="M50 23 C43 23 40 30 40 37 C40 44 44 46 50 46 C56 46 60 44 60 37 C60 30 57 23 50 23 Z" fill="${dc()}" stroke="none" opacity="0.85"/>
      <path d="M70 46 V52" fill="none" stroke-width="2"/><rect x="64" y="52" width="12" height="14" rx="3" fill="${GOLD}"/>`,
    erzmagier: () => `<path d="M76 18 V77" fill="none" stroke-width="4"/><circle cx="76" cy="14" r="7" fill="#c89bff"/>
      <path d="M48 3 L66 40 H32 Z"/><ellipse cx="49" cy="41" rx="23" ry="5"/>
      <path d="M49 18 l2.2 4.6 5 .7 -3.6 3.5 .9 5 -4.5-2.4 -4.5 2.4 .9-5 -3.6-3.5 5-.7z" fill="${GOLD}" stroke="none"/>
      <path d="M37 46 H61 L68 77 H30 Z"/>`,
    golem: () => `<rect x="37" y="11" width="26" height="19" rx="4"/>
      <rect x="42" y="18" width="5" height="4" fill="#7ff7ff" stroke="none"/><rect x="53" y="18" width="5" height="4" fill="#7ff7ff" stroke="none"/>
      <path d="M26 33 H74 L69 62 H31 Z"/><rect x="16" y="35" width="10" height="24" rx="3"/><rect x="74" y="35" width="10" height="24" rx="3"/>
      <rect x="35" y="62" width="30" height="15" rx="2"/><path d="M44 40 L50 48 L56 40 M50 48 V56" fill="none" stroke="#7ff7ff" stroke-width="2"/>`,
    katapult: () => `<path d="M40 50 L76 15" fill="none" stroke-width="6"/><circle cx="79" cy="12" r="7" fill="${dc()}"/>
      <path d="M27 77 L31 47 H35 V40 H43 V47 H57 V40 H65 V47 H69 L73 77 Z"/><circle cx="40" cy="52" r="4"/>`,
    hexe: () => `<path d="M48 4 C56 10 61 22 70 32 H28 C38 26 44 14 48 4 Z"/><ellipse cx="49" cy="33" rx="28" ry="5"/>
      <path d="M53 15 a6 6 0 1 0 4 10 a5 5 0 1 1 -4 -10z" fill="${GOLD}" stroke="none"/>
      <circle cx="50" cy="44" r="8"/><path d="M38 52 C41 62 35 70 30 77 H70 C65 70 59 62 62 52 Z"/>`,
    amazone: () => `<path d="M18 22 L82 74 M82 22 L18 74" fill="none" stroke="#dfe6f2" stroke-width="5"/>
      <path d="M38 27 L40 14 L46 22 L50 11 L54 22 L60 14 L62 27 Z"/>
      <path d="M32 58 C30 38 38 27 50 27 C62 27 70 38 68 58 Z"/><path d="M40 42 H60" fill="none" stroke="${dc()}" stroke-width="3"/>
      <path d="M36 58 H64 L69 77 H31 Z"/>`,
    waechter: () => `<path d="M46.5 5 h7 v5 h5 v6 h-5 v6 h-7 v-6 h-5 v-6 h5 Z"/>
      <path d="M50 22 C38 22 31 30 35 42 L38 50 H62 L65 42 C69 30 62 22 50 22 Z"/>
      <path d="M28 45 H72 V60 C72 70 62 78 50 85 C38 78 28 70 28 60 Z"/><path d="M50 50 V78 M37 60 H63" fill="none" stroke-width="2.5"/>`,
    kaiser: () => `<path d="M31 30 L35 8 L43 21 L50 4 L57 21 L65 8 L69 30 Z"/><rect x="31" y="30" width="38" height="8" rx="2"/>
      <path d="M50 38 C39 38 33 44 36 52 L40 60 H60 L64 52 C67 44 61 38 50 38 Z"/><path d="M37 60 H63 L69 77 H31 Z"/>
      <g fill="#6fbf5a" stroke="none"><ellipse cx="27" cy="40" rx="3" ry="6" transform="rotate(-25 27 40)"/><ellipse cx="25" cy="52" rx="3" ry="6" transform="rotate(-10 25 52)"/>
      <ellipse cx="73" cy="40" rx="3" ry="6" transform="rotate(25 73 40)"/><ellipse cx="75" cy="52" rx="3" ry="6" transform="rotate(10 75 52)"/></g>`,

    // ---------- neue Figuren ----------
    schleicher: () => `<circle cx="50" cy="28" r="12"/><path d="M37 25 H63 V31 H37 Z" fill="${dc()}" stroke="none"/>
      <circle cx="45" cy="28" r="1.6" fill="#fff" stroke="none"/><circle cx="55" cy="28" r="1.6" fill="#fff" stroke="none"/>
      <path d="M62 27 L74 22 L72 30 Z" fill="${dc()}" stroke="none"/>${PAWNBODY()}`,
    bogenschuetze: () => `<path d="M24 12 Q6 40 24 68" fill="none" stroke="#8a5a2b" stroke-width="5"/><path d="M24 12 L24 68" fill="none" stroke-width="1.5"/>
      <path d="M22 40 L44 40" fill="none" stroke-width="2.5"/><circle cx="56" cy="27" r="12"/>${PAWNBODY(56)}
      <path d="M48 17 L56 6 L64 17 Z" fill="#6fbf5a"/>`,
    fahnentraeger: () => `<path d="M72 82 V8" fill="none" stroke-width="4"/><path d="M72 9 L94 15 L72 23 Z" fill="${GOLD}"/>
      <circle cx="46" cy="27" r="12"/>${PAWNBODY(46)}`,
    grenadier: () => `<circle cx="46" cy="27" r="12"/><path d="M34 22 Q46 8 58 22 Z" fill="${dc()}" stroke="none"/>${PAWNBODY(46)}
      <circle cx="75" cy="58" r="10" fill="${dc()}"/><path d="M80 49 Q84 42 90 40" fill="none" stroke-width="2.5"/>
      <path d="M90 34 l2 4 4 1 -3 3 1 4 -4 -2 -4 2 1 -4 -3 -3 4 -1z" fill="#ff7a2f" stroke="none"/>`,
    zebra: () => `<path d="M33 77 C33 62 38 55 45 49 C39 50 31 54 26 50 C22 46 26 40 32 36 C39 30 42 22 50 18 L52 9 L58 17 C71 21 77 36 75 52 C74 62 70 70 70 77 Z"/>
      <path d="M46 24 L60 30 M42 36 L66 42 M40 48 L70 54 M42 60 L71 64" fill="none" stroke="${dc()}" stroke-width="3.5"/>
      <circle cx="47" cy="29" r="2.6" fill="#fff" stroke="none"/>`,
    giraffe: () => `<path d="M38 77 C38 62 44 52 50 46 L56 16 C57 10 64 8 70 12 L76 16 L70 20 L64 20 L62 46 C68 52 70 64 68 77 Z"/>
      <path d="M58 6 V12 M66 4 V10" fill="none" stroke-width="3"/>
      <circle cx="62" cy="15" r="2" fill="${dc()}" stroke="none"/><g fill="#c98a2b" stroke="none"><circle cx="55" cy="32" r="3"/><circle cx="50" cy="56" r="4"/><circle cx="59" cy="64" r="3.5"/><circle cx="56" cy="44" r="2.6"/></g>`,
    wolf: () => `<path d="M30 20 L38 34 L62 34 L70 20 L74 44 C74 56 64 66 50 66 C36 66 26 56 26 44 Z"/>
      <path d="M40 52 L50 62 L60 52 Z" fill="${dc()}" stroke="none"/><circle cx="41" cy="44" r="2.8" fill="#ffd23f" stroke="none"/><circle cx="59" cy="44" r="2.8" fill="#ffd23f" stroke="none"/>${BASEBODY.replace('M37 59', 'M37 64')}`,
    gaukler: () => `<circle cx="28" cy="14" r="6" fill="#ff5d4f"/><circle cx="50" cy="8" r="6" fill="#ffd23f"/><circle cx="72" cy="14" r="6" fill="#5fd068"/>
      <circle cx="50" cy="31" r="11"/>${PAWNBODY()}<path d="M30 52 L22 36 M70 52 L78 36" fill="none" stroke-width="4"/>`,
    fuchs: () => `<path d="M28 14 L40 32 L60 32 L72 14 L74 40 C74 50 62 58 50 70 C38 58 26 50 26 40 Z"/>
      <path d="M38 46 C44 52 56 52 62 46 L50 66 Z" fill="#fff" stroke="none" opacity=".85"/>
      <circle cx="41" cy="40" r="2.6" fill="${dc()}" stroke="none"/><circle cx="59" cy="40" r="2.6" fill="${dc()}" stroke="none"/><circle cx="50" cy="66" r="3" fill="${dc()}" stroke="none"/>
      <path d="M38 70 H62 L67 77 H33 Z"/>`,
    einhorn: () => `<path d="M33 77 C33 62 38 55 45 49 C39 50 31 54 26 50 C22 46 26 40 32 36 C39 30 42 22 50 18 L58 17 C71 21 77 36 75 52 C74 62 70 70 70 77 Z"/>
      <path d="M44 22 L34 2 L52 18 Z" fill="${GOLD}"/><path d="M60 20 C70 26 72 40 66 56" fill="none" stroke="#c89bff" stroke-width="4"/>
      <circle cx="47" cy="30" r="2.6" fill="${dc()}" stroke="none"/>`,
    ninja: () => `<circle cx="50" cy="30" r="15"/><path d="M35 26 H65 V34 H35 Z" fill="${dc()}" stroke="none"/>
      <path d="M43 30 H48 M52 30 H57" fill="none" stroke="#fff" stroke-width="2.5"/><path d="M64 26 L80 18 M64 32 L82 30" fill="none" stroke="#ff5d4f" stroke-width="3"/>
      <path d="M36 48 H64 L70 77 H30 Z"/><path d="M78 56 l4 -8 4 8 8 4 -8 4 -4 8 -4 -8 -8 -4z" fill="#dfe6f2"/>`,
    nachtreiter: () => `<path d="M33 77 C33 62 38 55 45 49 C39 50 31 54 26 50 C22 46 26 40 32 36 C39 30 42 22 50 18 L52 9 L58 17 C71 21 77 36 75 52 C74 62 70 70 70 77 Z"/>
      <path d="M80 6 a10 10 0 1 0 10 14 a8 8 0 1 1 -10 -14z" fill="${GOLD}" stroke="none"/>
      <circle cx="47" cy="29" r="2.6" fill="#b66cff" stroke="none"/><path d="M58 22 C66 30 68 44 64 58" fill="none" stroke="#b66cff" stroke-width="3"/>`,
    drache: () => `<path d="M24 46 C10 36 6 22 10 10 C18 22 30 28 40 36 Z"/><path d="M76 46 C90 36 94 22 90 10 C82 22 70 28 60 36 Z"/>
      <path d="M50 14 C64 14 72 26 70 40 C68 52 60 60 50 64 C40 60 32 52 30 40 C28 26 36 14 50 14 Z"/>
      <path d="M40 16 L34 4 L46 13 M60 16 L66 4 L54 13" fill="${GOLD}"/><circle cx="42" cy="34" r="3" fill="#ffd23f" stroke="none"/><circle cx="58" cy="34" r="3" fill="#ffd23f" stroke="none"/>
      <path d="M42 48 Q50 54 58 48" fill="none" stroke-width="2.5"/><path d="M36 62 H64 L69 77 H31 Z"/>`,
    elefant: () => `<path d="M24 26 C14 30 14 50 26 54 L32 44 Z"/><path d="M76 26 C86 30 86 50 74 54 L68 44 Z"/>
      <path d="M50 16 C64 16 70 28 68 40 C66 48 60 52 58 60 C57 68 60 72 64 72 L60 77 C52 76 49 70 50 62 C44 60 34 52 32 40 C30 28 36 16 50 16 Z"/>
      <circle cx="43" cy="36" r="2.6" fill="${dc()}" stroke="none"/><path d="M36 50 L28 62" fill="none" stroke="#fff" stroke-width="3"/><path d="M30 64 H50 L52 77 H28 Z"/>`,
    hofnarr: () => `<path d="M30 30 C26 14 18 10 10 14 C20 18 26 26 32 36 Z" fill="#ff5d4f"/><path d="M70 30 C74 14 82 10 90 14 C80 18 74 26 68 36 Z" fill="#5fd068"/>
      <path d="M50 30 C50 14 46 6 50 2 C54 6 50 14 50 30 Z" fill="${GOLD}"/><circle cx="10" cy="14" r="4" fill="${GOLD}"/><circle cx="90" cy="14" r="4" fill="${GOLD}"/>
      <circle cx="50" cy="42" r="12"/><path d="M44 46 Q50 51 56 46" fill="none" stroke-width="2"/>${BASEBODY}`,
    schattenlaeufer: () => `<circle cx="50" cy="13" r="5"/><path d="M50 19 C37 29 33 42 39 52 H61 C67 42 63 29 50 19 Z"/>
      <path d="M50 19 C40 30 36 46 30 77 H70 C64 46 60 30 50 19 Z" fill="${dc()}" opacity=".55" stroke="none"/>
      <path d="M44 34 H48 M52 34 H56" fill="none" stroke="#b66cff" stroke-width="3"/><path d="M42 57 Q41 68 33 77 H67 Q59 68 58 57 Z"/>`,
    alchemist: () => `<path d="M44 8 H56 V28 C68 34 72 46 68 56 C64 66 36 66 32 56 C28 46 32 34 44 28 Z"/>
      <path d="M36 50 C42 46 58 46 64 50 C64 58 36 58 36 50 Z" fill="#5fd068" stroke="none"/><circle cx="46" cy="42" r="2.5" fill="#fff" stroke="none"/><circle cx="56" cy="38" r="1.8" fill="#fff" stroke="none"/>
      <rect x="41" y="4" width="18" height="6" rx="2"/><path d="M38 64 H62 L67 77 H33 Z"/>`,
    kardinal: () => `<path d="M50 4 C62 12 66 24 62 36 H38 C34 24 38 12 50 4 Z" fill="#ff5d4f"/><path d="M50 12 V30 M43 19 H57" fill="none" stroke="${GOLD}" stroke-width="3.5"/>
      <path d="M38 36 H62 C64 46 60 54 56 58 H44 C40 54 36 46 38 36 Z"/>${COLLAR(57, 26)}<path d="M42 63 Q41 70 33 77 H67 Q59 70 58 63 Z"/>`,
    druide: () => `<path d="M24 77 L30 10" fill="none" stroke="#8a5a2b" stroke-width="5"/><path d="M30 10 C22 4 16 10 20 16 C26 18 30 14 30 10 Z M30 10 C36 2 44 6 40 12 C36 16 32 14 30 10 Z" fill="#5fd068"/>
      <path d="M56 12 C44 12 38 26 38 40 C38 54 34 66 32 77 H78 C76 66 72 54 72 40 C72 26 68 12 56 12 Z"/>
      <path d="M56 22 C49 22 46 29 46 36 C46 43 50 45 56 45 C62 45 66 43 66 36 C66 29 63 22 56 22 Z" fill="${dc()}" stroke="none" opacity=".85"/>
      <circle cx="52" cy="35" r="1.6" fill="#7ff7ff" stroke="none"/><circle cx="60" cy="35" r="1.6" fill="#7ff7ff" stroke="none"/>`,
    wachposten: () => `<path d="M34 24 H66 V30 H34 Z"/><path d="M40 30 H60 L64 77 H36 Z"/><path d="M38 24 L50 10 L62 24 Z"/>
      <path d="M50 10 V2 L62 6 L50 9" fill="${GOLD}"/><rect x="45" y="38" width="10" height="12" rx="5" fill="${dc()}" stroke="none"/>`,
    bergtroll: () => `<path d="M30 30 C30 16 70 16 70 30 L74 60 C74 70 26 70 26 60 Z"/>
      <circle cx="42" cy="34" r="3" fill="${dc()}" stroke="none"/><circle cx="58" cy="34" r="3" fill="${dc()}" stroke="none"/><path d="M42 46 L46 50 L50 46 L54 50 L58 46" fill="none" stroke-width="2.5"/>
      <path d="M78 24 C88 22 92 30 88 36 L80 72" fill="#8a5a2b"/><path d="M34 66 H66 L69 77 H31 Z"/>`,
    yeti: () => `<path d="M50 12 C68 12 76 24 76 42 C76 58 68 70 50 70 C32 70 24 58 24 42 C24 24 32 12 50 12 Z"/>
      <path d="M36 14 L30 4 L42 12 M64 14 L70 4 L58 12" fill="#dfe6f2"/><path d="M36 32 C40 28 60 28 64 32 C66 44 60 52 50 52 C40 52 34 44 36 32 Z" fill="#9fd8ff" stroke="none"/>
      <circle cx="44" cy="38" r="2.5" fill="${dc()}" stroke="none"/><circle cx="56" cy="38" r="2.5" fill="${dc()}" stroke="none"/><path d="M45 46 H55" fill="none" stroke-width="2"/><path d="M34 68 H66 L69 77 H31 Z"/>`,
    ballista: () => `<path d="M16 28 Q50 10 84 28" fill="none" stroke="#8a5a2b" stroke-width="6"/><path d="M16 28 L50 36 L84 28" fill="none" stroke-width="2"/>
      <path d="M50 12 V54" fill="none" stroke-width="4"/><path d="M50 6 L56 16 H44 Z" fill="#dfe6f2"/>
      <path d="M30 77 L34 50 H66 L70 77 Z"/><path d="M38 50 V42 H46 V50 M54 50 V42 H62 V50" />`,
    titan: () => `<path d="M28 34 C28 14 72 14 72 34 V48 H28 Z"/><path d="M50 12 V4" fill="none" stroke-width="5"/><path d="M44 4 H56" fill="none" stroke="${GOLD}" stroke-width="5"/>
      <path d="M34 34 H66 V40 H34 Z" fill="${dc()}" stroke="none"/><path d="M50 40 V48" fill="none" stroke-width="3"/>
      <path d="M20 50 H80 L72 62 H28 Z"/><path d="M32 62 H68 L72 77 H28 Z"/>`,
    kraken: () => `<path d="M50 6 C66 6 74 18 72 32 C70 42 62 46 50 46 C38 46 30 42 28 32 C26 18 34 6 50 6 Z"/>
      <circle cx="42" cy="30" r="4" fill="#fff" stroke="none"/><circle cx="58" cy="30" r="4" fill="#fff" stroke="none"/><circle cx="42" cy="30" r="2" fill="${dc()}" stroke="none"/><circle cx="58" cy="30" r="2" fill="${dc()}" stroke="none"/>
      <path d="M32 42 C22 52 30 64 18 72 M42 46 C38 58 46 66 38 76 M58 46 C62 58 54 66 62 76 M68 42 C78 52 70 64 82 72" fill="none" stroke-width="7"/>`,
    herzogin: () => `<path d="M38 22 L40 10 L46 17 L50 7 L54 17 L60 10 L62 22 Z" fill="${GOLD}"/>
      <circle cx="50" cy="30" r="9"/><path d="M38 42 C40 56 32 66 28 77 H72 C68 66 60 56 62 42 Z"/>${COLLAR(39, 28)}`,
    walkuere: () => `<path d="M30 24 C18 16 10 18 6 12 C10 26 20 32 32 32 Z" fill="#fff"/><path d="M70 24 C82 16 90 18 94 12 C90 26 80 32 68 32 Z" fill="#fff"/>
      <path d="M32 34 C32 18 68 18 68 34 V40 H32 Z"/><path d="M42 34 H58" fill="none" stroke="${dc()}" stroke-width="3"/>
      <path d="M36 40 H64 C66 52 60 60 56 62 H44 C40 60 34 52 36 40 Z"/><path d="M34 62 H66 L70 77 H30 Z"/>`,
    sphinx: () => `<path d="M30 40 C30 16 70 16 70 40 L76 62 H24 Z" fill="${GOLD}"/><path d="M34 28 H66 M32 40 H68 M30 52 H70" fill="none" stroke="#4f9cf5" stroke-width="3"/>
      <path d="M40 30 C40 22 60 22 60 30 V46 C60 54 40 54 40 46 Z"/><circle cx="45" cy="36" r="2.2" fill="${dc()}" stroke="none"/><circle cx="55" cy="36" r="2.2" fill="${dc()}" stroke="none"/>
      <path d="M26 62 H74 L76 77 H24 Z"/>`,
    phoenix: () => `<path d="M48 54 C32 44 16 46 6 30 C14 50 26 60 42 62 Z" fill="#ff7a2f"/><path d="M52 54 C68 44 84 46 94 30 C86 50 74 60 58 62 Z" fill="#ff7a2f"/>
      <path d="M50 14 C58 14 64 22 62 32 L72 36 L62 38 C60 46 56 52 50 56 C44 52 40 44 40 34 C40 24 44 14 50 14 Z"/>
      <path d="M46 14 C44 6 50 2 52 8 C54 2 60 4 56 14" fill="#ffd23f"/><circle cx="54" cy="27" r="2.4" fill="${dc()}" stroke="none"/><path d="M38 60 H62 L67 77 H33 Z"/>`,
    feldherr: () => `<path d="M58 6 C70 4 76 12 72 20 C66 16 60 18 56 22 Z" fill="#ff5d4f"/>
      <path d="M34 34 C34 18 66 18 66 34 V38 H34 Z"/><path d="M30 38 H70" fill="none" stroke-width="5"/>
      <path d="M50 40 C40 40 34 46 37 54 L40 60 H60 L63 54 C66 46 60 40 50 40 Z"/><path d="M37 60 H63 L69 77 H31 Z"/>`,
    sultan: () => `<path d="M26 28 C26 12 74 12 74 28 C74 38 26 38 26 28 Z"/><path d="M30 22 C40 28 60 28 70 22" fill="none" stroke-width="2.5"/>
      <circle cx="50" cy="20" r="5" fill="#ff5d4f"/><path d="M50 12 C52 6 56 4 58 2" fill="none" stroke="#fff" stroke-width="3"/>
      <path d="M50 36 C39 36 33 44 36 52 L40 60 H60 L64 52 C67 44 61 36 50 36 Z"/><path d="M37 60 H63 L69 77 H31 Z"/>`,
    pharao: () => `<path d="M30 52 L32 20 C34 8 66 8 68 20 L70 52 L60 46 V30 H40 V46 Z" fill="${GOLD}"/><path d="M33 26 H40 M33 34 H40 M33 42 H40 M60 26 H67 M60 34 H67 M60 42 H67" fill="none" stroke="#4f9cf5" stroke-width="3"/>
      <path d="M40 24 H60 V44 C60 52 40 52 40 44 Z"/><circle cx="45" cy="34" r="2.2" fill="${dc()}" stroke="none"/><circle cx="55" cy="34" r="2.2" fill="${dc()}" stroke="none"/>
      <path d="M46 52 H54 V60 H46 Z" fill="${GOLD}"/><path d="M37 60 H63 L69 77 H31 Z"/>`
  };

  // Spielfiguren im Cel-Shading-Stil: Teamfarbe (Blau = Weiß, Rot = Schwarz),
  // dicke dunkle Kontur, harte Schattenkante, Sockel. Meisterstufe = goldener Sockel + Stern.
  function svgFor(type, color, master) {
    const def = GJ.PIECES[type];
    const team = color === 'w' ? 'blue' : 'red';
    const baseFill = master ? '#ffc83d' : (color === 'w' ? '#1f4fa3' : '#9e2a22');
    return `<svg viewBox="0 0 100 100" class="pc-svg${master ? ' master' : ''}" xmlns="http://www.w3.org/2000/svg">` +
      `<ellipse cx="50" cy="92" rx="31" ry="5.5" fill="${INK}" opacity=".28"/>` +
      `<g fill="url(#gj-${team})" stroke="${INK}" stroke-width="4.5" stroke-linejoin="round" stroke-linecap="round">` + ART[type](color) + '</g>' +
      `<rect x="17" y="75" width="66" height="14" rx="6" fill="${baseFill}" stroke="${INK}" stroke-width="4.5"/>` +
      `<rect x="23" y="78.5" width="20" height="3.2" rx="1.6" fill="#fff" opacity=".5"/>` +
      gem(def.rarity) +
      (master ? `<path d="M82 6 l3.2 6.5 7.2 1 -5.2 5 1.2 7.1 -6.4-3.4 -6.4 3.4 1.2-7.1 -5.2-5 7.2-1z" fill="#ffc83d" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/>` : '') +
      '</svg>';
  }

  GJ._pk = { sym, lv, inf, vtxt, zug, E, V, sm, eachInRadius, step, tOk, sumV, radiusReach, lineReach, fwd, DIRSETS, svgFor, ART };
})();
