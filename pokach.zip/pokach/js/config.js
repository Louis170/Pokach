/* =====================================================================
   POKACH - config.js
   Alle Balancing-Zahlen an einem Ort. Hier darfst du frei drehen.
   ===================================================================== */

var GJ = globalThis.GJ = globalThis.GJ || {};

GJ.CONFIG = {
  version: 2,
  appName: 'Pokach',
  saveKey: 'pokach_v1',

  // ---------------- Seltenheiten ----------------
  // factor = Multiplikator für Upgrade-Kosten
  rarity: {
    standard:    { name: 'Standard',    color: '#c9d2e3', factor: 1.0, order: 0 },
    gewoehnlich: { name: 'Gewöhnlich',  color: '#5fd068', factor: 1.0, order: 1 },
    selten:      { name: 'Selten',      color: '#4f9cf5', factor: 1.4, order: 2 },
    episch:      { name: 'Episch',      color: '#b66cff', factor: 2.0, order: 3 },
    legendaer:   { name: 'Legendär',    color: '#ffb02e', factor: 3.0, order: 4 }
  },

  // ---------------- Regeln ----------------
  rules: {
    // Kein Schachmatt in den ersten so vielen Halbzügen (28 = je 14 Züge).
    // Damit dauert jede Partie mindestens 15 Züge pro Seite.
    mateProtectPly: 28,
    // Specials erst ab dem so-vielten eigenen Zug (1 = sofort)
    specialsFromMove: 4,
    // Wer anfängt, wird ausgelost
    randomFirst: true
  },

  // ---------------- Wirtschaft ----------------
  economy: {
    startEP: 150,
    drawFactor: 0.10,         // Remis = 10 % der Grund-EP ...
    drawMinPly: 40,           // ... aber nur, wenn die Partie mindestens so viele Halbzüge hatte
    lossEP: 10,               // Trostpreis bei Niederlage
    lossMinPly: 30,           // ... nur wenn man so lange durchgehalten hat
    resignEP: 0,
    fastMateMoves: 30,        // Matt in höchstens so vielen eigenen Zügen
    fastMateBonus: 0.20,
    streakBonusPerWin: 0.10,
    streakBonusMax: 0.50,
    firstWinBonus: 150,       // einmalig pro Bot
    dailyFirstWin: 0.5,       // erster Sieg des Tages: +50 %
    // Upgrade-Kosten Stufe 1/2/3, mal Seltenheitsfaktor
    upgradeCost: [500, 1400, 3500],
    duplicateEP: { gewoehnlich: 40, selten: 90, episch: 220, legendaer: 600 },
    // Tagesbelohnung: Tag 1 bis 7 einer Serie, danach wieder von vorn
    daily: [40, 60, 80, 100, 130, 160, 300]
  },

  // ---------------- Deck ----------------
  deck: {
    budget: 40,
    slots: 5,
    maxCopies: { standard: 99, gewoehnlich: 99, selten: 3, episch: 2, legendaer: 1 }
  },

  // ---------------- Spielautomat ----------------
  slot: {
    spinCost: 150,
    // Wahrscheinlichkeiten pro Dreh (Rest = Niete)
    odds: {
      gewoehnlich: 0.090,
      selten: 0.030,
      episch: 0.008,
      legendaer: 0.0015,
      coins: 0.16,       // 3 Münzen
      bag: 0.03,         // 3 Geldsäcke
      clover: 0.05       // 3 Kleeblätter = Freidreh
    },
    payout: { coins: 100, bag: 450 },
    nearMissChance: 0.45,
    pityNew: 25,              // nach so vielen Drehs ohne neue Figur: garantiert neue (gewöhnlich/selten)
    pityLegendary: 220,       // nach so vielen Drehs ohne Legendär: garantiert Legendär
    stripWeights: { gewoehnlich: 4, selten: 3, episch: 2, legendaer: 1, coin: 4, bag: 2, clover: 3, coal: 5 },
    reelStops: [900, 1500, 2300],
    suspenseExtra: 1500
  },

  // ---------------- KI ----------------
  ai: {
    specialReserve: 0.20,
    frozenPenalty: 0.30,
    maxMs: 3500,
    minShowMs: 450
  },

  // ---------------- Specials (Werte pro Stufe 1/2/3) ----------------
  specials: {
    // Standardfiguren
    bauer:         { range: [2, 2, 3], secondHit: [false, false, true], maxValue: [5, 5, 9] },
    springer:      { jumps: [2, 2, 3], firstCanCapture: [false, true, true], maxCaps: [1, 1, 2] },
    laeufer:       { range: [6, 7, 7], hits: [1, 1, 2] },
    turm:          { range: [3, 4, 5], maxCaps: [1, 1, 2] },
    dame:          { radius: [1, 1, 2], dur: [1, 1, 1] },
    koenig:        { radius: [1, 2, 3], shieldSwapped: [0, 0, 1] },
    // Bisherige Sonderfiguren (abgeschwächt)
    spaeher:       { radius: [1, 1, 2], dur: [1, 2, 2] },
    lanzentraeger: { minDist: 2, maxDist: [2, 3, 4], diag: [false, true, true], maxValue: [3, 5, 9] },
    kamelreiter:   { dist: [1, 2, 2], crush: [false, false, true] },
    greif:         { radius: [2, 3, 3], maxValue: [3, 3, 5], freezePawns: [false, false, true] },
    moench:        { radius: [1, 1, 1], pawnOnly: [true, true, false], maxValue: [1.8, 1.8, 3] },
    erzmagier:     { radius: [1, 2, 2], maxValue: [3, 5, 5], chain: [false, false, true] },
    golem:         { freezeRadius: [1, 1, 2], crushRadius: [0, 1, 1], dur: [1, 1, 1] },
    katapult:      { minDist: 2, maxDist: [5, 6, 7], maxValue: [5, 5, 9], splash: [false, false, true] },
    hexe:          { range: [3, 5, 7], maxValue: [3, 5, 5], freeze: [0, 0, 1] },
    amazone:       { max: [1, 2, 2] },
    waechter:      { radius: [1, 1, 2], dur: [1, 2, 2] },
    kaiser:        { maxValue: [1.8, 3.5, 5] },
    // Neue Figuren
    schleicher:    { max: [2, 3, 4], dur: [1, 1, 2] },
    bogenschuetze: { min: 2, max: [3, 4, 5], maxValue: [3, 3, 5] },
    fahnentraeger: { count: [1, 1, 2], shield: [0, 1, 1] },
    grenadier:     { min: 2, max: [2, 3, 3], maxValue: [3, 5, 5], splash: [false, true, true] },
    zebra:         { radius: [2, 3, 3] },
    giraffe:       { max: [2, 3, 4], dur: [1, 1, 2] },
    wolf:          { radius: [2, 2, 2], maxValue: [1.8, 3, 3.5] },
    gaukler:       { radius: [2, 3, 4], shield: [0, 0, 1] },
    fuchs:         { radius: [1, 1, 1], maxValue: [1.8, 3, 5] },
    einhorn:       { maxValue: [3, 3.5, 5] },
    ninja:         { min: 2, max: [2, 3, 4], dur: [1, 2, 2] },
    nachtreiter:   { radius: [2, 3, 3], maxValue: [3, 3, 5] },
    drache:        { range: [2, 3, 3], hits: [1, 1, 2], maxValue: [3, 5, 9] },
    elefant:       { range: [2, 2, 3], maxValue: [1.8, 3, 3.5] },
    hofnarr:       { range: [3, 4, 5], steps: [1, 2, 2], maxValue: [3, 5, 9] },
    schattenlaeufer: { radius: [2, 3, 4] },
    alchemist:     { radius: [1, 2, 2], maxValue: [3, 5, 9] },
    kardinal:      { radius: [1, 2, 2], dur: [1, 1, 2] },
    druide:        { radius: [1, 1, 2], dur: [1, 2, 2] },
    wachposten:    { max: [3, 4, 5], dur: [1, 1, 2] },
    bergtroll:     { dist: [1, 2, 2], crush: [false, false, true] },
    yeti:          { radius: [1, 1, 2], dur: [1, 1, 1] },
    ballista:      { min: 2, max: [4, 5, 6], maxValue: [3, 5, 5] },
    titan:         { range: [2, 3, 4], maxValue: [3, 5, 9] },
    kraken:        { range: [2, 3, 4], dur: [1, 1, 1] },
    herzogin:      { radius: [1, 1, 2], dur: [1, 2, 2] },
    walkuere:      { radius: [1, 2, 2], dur: [1, 1, 1] },
    sphinx:        { range: [3, 5, 7], dur: [1, 2, 2], maxValue: [5, 9, 99] },
    phoenix:       { radius: [1, 1, 2], freeze: [false, true, true] },
    feldherr:      { count: [1, 2, 2], shield: [0, 0, 1] },
    sultan:        { radius: [2, 3, 3] },
    pharao:        { radius: [1, 1, 2], dur: [1, 1, 1] }
  },

  // ---------------- Bots ----------------
  // depth = maximale Suchtiefe, timeMs = Bedenkzeit
  // Decks: Felder aus Sicht des Bots als wäre er Weiß (Reihe 1 und 2). Wird gespiegelt.
  bots: [
    {
      id: 'bernd', name: 'Bauer Bernd', title: 'Der Rekrut', stars: 1, ep: 60,
      depth: 1, timeMs: 400, randomChance: 0.35, randomTop: 5, quiescence: false, tt: false, noise: 60,
      deck: 'CLASSIC', levels: {}, color: '#7cc36b'
    },
    {
      id: 'rosa', name: 'Ritterin Rosa', title: 'Die Klingenschwingerin', stars: 1, ep: 90,
      depth: 2, timeMs: 600, randomChance: 0.15, randomTop: 3, quiescence: false, tt: false, noise: 35,
      deck: {
        a1: 'turm', b1: 'laeufer', c1: 'springer', d1: 'dame', e1: 'koenig', f1: 'springer', g1: 'laeufer', h1: 'turm',
        a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'bauer', e2: 'bauer', f2: 'bauer', g2: 'bauer', h2: 'bauer'
      },
      levels: { bauer: 1, springer: 1 }, color: '#ff7aa8'
    },
    {
      id: 'grimm', name: 'General Grimm', title: 'Der Stratege', stars: 2, ep: 130,
      depth: 3, timeMs: 1000, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 18,
      deck: {
        a1: 'golem', b1: 'kamelreiter', c1: 'laeufer', d1: 'dame', e1: 'koenig', f1: 'laeufer', g1: 'springer', h1: 'golem',
        a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'spaeher', e2: 'spaeher', f2: 'bauer', g2: 'bauer', h2: 'bauer'
      },
      levels: { bauer: 1, golem: 1, kamelreiter: 1, spaeher: 1 }, color: '#7aa2ff'
    },
    {
      id: 'perla', name: 'Piratin Perla', title: 'Schrecken der Sieben Felder', stars: 2, ep: 170,
      depth: 3, timeMs: 1200, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 12,
      deck: {
        a1: 'turm', b1: 'zebra', c1: 'bogenschuetze', d1: 'dame', e1: 'koenig', f1: 'laeufer', g1: 'springer', h1: 'ballista',
        a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'bauer', e2: 'bauer', f2: 'bauer', g2: 'bauer'
      },
      levels: { turm: 1, zebra: 1, bogenschuetze: 2, dame: 1, ballista: 1, bauer: 1 }, color: '#2fb8a5'
    },
    {
      id: 'morgana', name: 'Morgana die Hexe', title: 'Meisterin der Flüche', stars: 3, ep: 220,
      depth: 4, timeMs: 1500, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 8,
      deck: {
        a1: 'turm', b1: 'springer', c1: 'moench', d1: 'hexe', e1: 'koenig', f1: 'moench', g1: 'greif', h1: 'katapult',
        a2: 'bauer', b2: 'bauer', c2: 'spaeher', d2: 'bauer', e2: 'spaeher', f2: 'bauer', g2: 'bauer', h2: 'bauer'
      },
      levels: { turm: 1, springer: 1, moench: 2, hexe: 2, koenig: 1, greif: 1, katapult: 2, bauer: 1, spaeher: 1 }, color: '#b56cff'
    },
    {
      id: 'blitz', name: 'Baron von Blitz', title: 'Der Schnellste im Reich', stars: 3, ep: 270,
      depth: 4, timeMs: 1700, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 6,
      deck: {
        a1: 'turm', b1: 'einhorn', c1: 'laeufer', d1: 'erzmagier', e1: 'waechter', f1: 'laeufer', g1: 'wolf', h1: 'turm',
        a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'schleicher', e2: 'schleicher', f2: 'bauer', g2: 'bauer', h2: 'bauer'
      },
      levels: { turm: 2, einhorn: 2, laeufer: 2, erzmagier: 2, waechter: 2, wolf: 2, schleicher: 2, bauer: 2 }, color: '#ffd23f'
    },
    {
      id: 'freya', name: 'Frostkönigin Freya', title: 'Herrin des ewigen Eises', stars: 4, ep: 330,
      depth: 5, timeMs: 2000, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 4,
      deck: {
        a1: 'yeti', b1: 'springer', c1: 'druide', d1: 'dame', e1: 'pharao', f1: 'laeufer', g1: 'springer', h1: 'wachposten',
        a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'bauer', e2: 'bauer', f2: 'bauer', g2: 'giraffe', h2: 'bauer'
      },
      levels: { yeti: 2, springer: 2, druide: 2, dame: 2, pharao: 2, laeufer: 2, wachposten: 2, giraffe: 2, bauer: 2 }, color: '#9fd8ff'
    },
    {
      id: 'draco', name: 'Drachenlord Draco', title: 'Feuer und Flamme', stars: 4, ep: 400,
      depth: 5, timeMs: 2400, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 2,
      deck: {
        a1: 'turm', b1: 'springer', c1: 'laeufer', d1: 'drache', e1: 'koenig', f1: 'laeufer', g1: 'springer', h1: 'turm',
        a2: 'bauer', b2: 'bauer', c2: 'grenadier', d2: 'bauer', e2: 'bauer', f2: 'bauer', g2: 'bauer', h2: 'bauer'
      },
      levels: { turm: 3, springer: 2, laeufer: 2, drache: 2, koenig: 2, grenadier: 2, bauer: 2 }, color: '#ff7a2f'
    },
    {
      id: 'gustav', name: 'Großmeister Gustav', title: 'Hat jedes Buch gelesen', stars: 5, ep: 480,
      depth: 6, timeMs: 3000, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 0,
      deck: 'CLASSIC',
      levels: { bauer: 3, springer: 3, laeufer: 3, turm: 3, dame: 3, koenig: 3 }, color: '#8a7a66'
    },
    {
      id: 'spiegel', name: 'Spiegel-Duell', title: 'Du gegen dich selbst', stars: 5, ep: 550,
      depth: 6, timeMs: 3000, randomChance: 0, randomTop: 1, quiescence: true, tt: true, noise: 0,
      deck: 'MIRROR', levels: 'MIRROR', color: '#ffd36b'
    }
  ]
};

GJ.CONFIG.CLASSIC_DECK = {
  a1: 'turm', b1: 'springer', c1: 'laeufer', d1: 'dame', e1: 'koenig', f1: 'laeufer', g1: 'springer', h1: 'turm',
  a2: 'bauer', b2: 'bauer', c2: 'bauer', d2: 'bauer', e2: 'bauer', f2: 'bauer', g2: 'bauer', h2: 'bauer'
};

// ---------------- Lokaler Multiplayer (1 gegen 1 auf einem Gerät) ----------------
GJ.CONFIG.mp = {
  defaultLevel: 1,          // Special-Stufe aller Figuren
  budgets: [40, 60, 80, 0], // 0 = kein Limit
  defaultBudget: 40
};

// ---------------- Online-Multiplayer ----------------
GJ.CONFIG.online = {
  // PeerJS (WebRTC) für die Verbindung, kostenloser öffentlicher Vermittlungsserver
  peerjsUrl: 'https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js',
  prefix: 'pokach-v1-',
  lobbySlots: 8,            // so viele Spieler pro WLAN werden gefunden
  ipEndpoints: ['/api/ip', 'https://api.ipify.org?format=json'],
  level: 'own',             // Online spielt jeder mit seinen eigenen Stufen
  budget: 40,
  turnSeconds: 0            // 0 = keine Zugzeit
};
