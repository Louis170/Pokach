/* POKACH - Service Worker: macht das Spiel offline spielbar.
   Bei jeder neuen Version VERSION erhöhen, dann holen sich alle Geräte die neuen Dateien. */
const VERSION = 'pokach-1.0.0';
const FILES = [
  './',
  './index.html',
  './manifest.json',
  "./css/style.css",
  "./fonts/erica-one.ttf",
  "./fonts/national-park-400.ttf",
  "./fonts/national-park-700.ttf",
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./js/ai.js",
  "./js/audio.js",
  "./js/config.js",
  "./js/deck.js",
  "./js/engine.js",
  "./js/fx.js",
  "./js/icons.js",
  "./js/main.js",
  "./js/match.js",
  "./js/net.js",
  "./js/pieces-art.js",
  "./js/pieces.js",
  "./js/save.js",
  "./js/slot.js",
  "./js/training.js",
  "./js/ui-board.js",
  "./js/ui-screens.js",
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  // Online-Dienste (PeerJS, IP-Abfrage) nie aus dem Cache
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  // Netz zuerst (damit Updates sofort ankommen), sonst Cache
  e.respondWith(fetch(e.request).then(r => {
    const copy = r.clone();
    caches.open(VERSION).then(c => c.put(e.request, copy)).catch(() => {});
    return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: true })));
});
