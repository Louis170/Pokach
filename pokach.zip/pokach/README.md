# Pokach

Schach mit 50 Sammelfiguren, Spezialattacken, Spielautomat, 10 Bots, 1 gegen 1 auf einem Gerät und Online-Duellen im selben WLAN.
Reines HTML, CSS und JavaScript, kein Build-Schritt. Nachfolger von Gambit Jackpot.

## Ordner

```
index.html          Startseite
manifest.json       App-Infos (Installieren auf dem Homescreen)
sw.js               Service Worker (offline spielbar)
vercel.json         Einstellungen für Vercel
api/ip.js           Vercel-Funktion für die WLAN-Erkennung (nur auf Vercel aktiv)
css/style.css       Aussehen
fonts/, icons/      Schriften und App-Icons
js/config.js        ALLE Zahlen: Wirtschaft, Automat, Regeln, Special-Werte, Bots
js/pieces-art.js    Zeichnungen der 50 Figuren
js/pieces.js        Figuren, Bewegungen und Specials
js/engine.js        Schachregeln (ohne Grafik)
js/ai.js            Bots
js/net.js           Online-Modus
js/match.js         Ablauf einer Partie
js/ui-*.js, deck.js, slot.js, save.js, audio.js, fx.js, icons.js, training.js, main.js
```

## Auf GitHub hochladen

1. Auf github.com einloggen, oben rechts **+** und **New repository**. Name z. B. `pokach`, **Public**, auf **Create repository** tippen.
2. Auf der leeren Repo-Seite **uploading an existing file** antippen.
3. Den **Inhalt** des entpackten Ordners `pokach` hineinziehen (also `index.html`, `js`, `css` usw., nicht den Ordner selbst). Auf dem iPad: Dateien-App, ZIP antippen zum Entpacken, dann in der GitHub-Seite über "choose your files" alles auswählen. Ordner lassen sich auf dem iPad nicht immer hochladen, dann die Ordner einzeln anlegen: Dateiname `js/config.js` eintippen legt den Ordner `js` automatisch an. Einfacher geht es am PC.
4. Unten **Commit changes**.

Wichtig: `index.html` muss ganz oben im Repo liegen, nicht in einem Unterordner.

### Optional: GitHub Pages
Repo, **Settings**, **Pages**, bei Branch `main` und `/ (root)` wählen, **Save**. Nach 1 bis 2 Minuten läuft das Spiel unter `https://DEINNAME.github.io/pokach/`.
Auf GitHub Pages gibt es die Funktion `api/ip.js` nicht, das Spiel nutzt dann automatisch einen anderen Dienst (api.ipify.org) für die WLAN-Erkennung.

## Auf Vercel veröffentlichen

1. Auf vercel.com mit dem GitHub-Konto einloggen.
2. **Add New**, **Project**, das Repo `pokach` auswählen, **Import**.
3. Framework Preset: **Other**. Build Command und Output Directory leer lassen.
4. **Deploy**. Danach läuft das Spiel unter `https://pokach-XXXX.vercel.app`.

Jede Änderung, die du auf GitHub hochlädst, landet automatisch nach etwa einer Minute auf Vercel.
Nach einem Update im Spiel einmal neu laden (bei installierter App: App schließen und neu öffnen). Bei größeren Updates in `sw.js` die Zeile `VERSION` erhöhen, dann holen sich alle Geräte sicher die neuen Dateien.

Hinweis: Pokach speichert unter einem neuen Speicherschlüssel. Der alte Fortschritt aus Gambit Jackpot wird nicht übernommen, weil Preise, Chancen und Figuren komplett neu sind. Alle starten mit 150 EP.

## Online spielen

- Beide Geräte öffnen dieselbe Adresse (z. B. die Vercel-Seite) und tippen auf **Online**.
- Geräte im selben WLAN finden sich automatisch und erscheinen unter "Gefundene Spieler". **Herausfordern** antippen, der andere nimmt an.
- Klappt die Erkennung nicht (Schul-WLAN, Handynetz, Gast-WLAN mit getrennten Geräten): Unter "Dein Code" steht ein Code. Den tippt der andere bei "Code des Freundes" ein und tippt auf **Verbinden**. Das klappt auch über verschiedene Netze hinweg.
- Technik: WebRTC über den kostenlosen PeerJS-Vermittlungsserver. Dafür braucht es Internet. Ein Browser darf das WLAN nicht selbst durchsuchen, deshalb läuft die Erkennung über die gemeinsame öffentliche IP.
- Online-Partien geben keine EP, damit niemand mit zwei Geräten EP sammelt.
- Testen ohne zweites Gerät: `index.html?nettest=1` in zwei Tabs desselben Browsers öffnen (über einen Webserver, nicht per Doppelklick).

## Regeln, die neu sind

- **Münzwurf**: Wer anfängt, wird ausgelost (`rules.randomFirst`).
- **Kein schnelles Matt**: In den ersten 28 Halbzügen ist ein Zug, der Schachmatt setzen würde, nicht erlaubt. Matt ist frühestens im 15. Zug möglich (`rules.mateProtectPly`).
- **Specials ab Zug 4** (`rules.specialsFromMove`).
- **Königstausch und Fliegender Teppich** gehen nicht, solange der König im Schach steht. Dadurch enden Partien wieder mit Matt.
- **Remis anbieten** gibt es gegen Bots nicht mehr (war der EP-Trick). Remis bringt nur noch 10 % der EP und erst nach 40 Halbzügen.
- **Rochade**: König antippen, dann g1/c1 **oder den Turm** antippen.
- Wenn du im Schach stehst und nur ein Special retten kann, sagt dir das Spiel das jetzt.
- Umwandlung nur noch in Figuren bis Wert 9 (keine Amazone, Sphinx usw.).
- Neue Wertgrenzen: Viele Specials können nur Figuren bis zu einem bestimmten Wert treffen (steht im Codex).

## Balancing ändern

Alles steht in `js/config.js`:
- `economy`: Belohnungen, Upgrade-Kosten, Tagesbelohnung
- `slot`: Kosten, Chancen, Glückszähler
- `deck`: Budget und Exemplar-Limits
- `specials`: Reichweiten und Werte jedes Specials pro Stufe
- `bots`: Stärke (`depth`, `timeMs`, `noise`), Decks und Stufen
- Figurwerte und Deck-Kosten stehen direkt bei der Figur in `js/pieces.js` (`value`, `cost`).

## Werte der Figuren (Kurzüberblick)

Die Werte orientieren sich an bekannten Märchenschach-Werten (z. B. Kamel ca. 2,3, Zebra ca. 2, Kanzler/Turm+Springer ca. 9, Erzbischof/Läufer+Springer ca. 8,5, Amazone ca. 12). Deck-Kosten liegen bei Wert plus kleinem Aufschlag für starke Specials. Seltenheit bedeutet ungewöhnliche Fähigkeiten, nicht mehr Kraft pro Punkt.

## Änderungen gegenüber Gambit Jackpot

Fehler behoben:
- Königstausch machte beide Figuren unsichtbar (Animation blieb "hängen").
- Greif blieb nach dem Sturzflug riesig.
- 1 gegen 1 endete nie: der König konnte sich per Special immer aus dem Schach tauschen.
- Bots (General Grimm, Morgana) patzten, weil sie bei Zeitnot auf Tiefe 1 zurückfielen und im Schach falsch rechneten.
- Remis-EP-Trick entfernt.
- Rochade auch per Antippen des Turms.
- Dicke, schwer lesbare Zahlen auf Knöpfen.

Neu: 32 neue Figuren (50 insgesamt), 5 neue Bots (10 insgesamt), Online-Modus, Tagesbelohnung, erster Sieg des Tages, Geldsack und Kleeblatt (Freidreh) am Automaten, viel seltenere gute Figuren, deutlich teurere Upgrades.

Schriften: Erica One, National Park (SIL Open Font License).
